# 流译 FlowTranslate

> 滑动即译。让外文屏幕文字像母语一样，跟着你的手指走。

流译是一个 Android 实时屏幕翻译器。它不是“截图 → 等结果 → 再看”的工具，而是把译文做成一层**跟着内容滚动**的悬浮层：你滑动小说、漫画、游戏、网页时，已经翻译过的段落会以 60/120 Hz 跟随，不会等 OCR，也不会闪一下白块再消失。

参考产品「瞬译」擅长静态截图翻译；流译专注解决它做不到的部分：**滚动过程中的连续性**。

> 当前是 v0.1 开发版，需要 Android 8.0+ 和一台真机。项目没有在应用商店上架，建议通过 GitHub Actions 构建后侧载安装。

---

## 目录

- [它解决什么问题](#它解决什么问题)
- [特性](#特性)
- [30 秒构建安装（不用装 Android Studio）](#30-秒构建安装不用装-android-studio)
- [本地构建](#本地构建)
- [手机上怎么用](#手机上怎么用)
- [为什么滚动不卡、不拖影](#为什么滚动不卡不拖影)
- [真实边界](#真实边界)
- [翻译引擎](#翻译引擎)
- [调参](#调参)
- [项目结构](#项目结构)
- [隐私与权限](#隐私与权限)
- [常见问题](#常见问题)
- [GitHub 建仓库教程](#github-建仓库教程)
- [License](#license)

---

## 它解决什么问题

传统屏幕翻译的流程是：

```
截图 → OCR → 翻译 → 把译文贴回屏幕（静止）
```

一旦你开始滑动，旧译文还停在原地，新文字还没识别，体验立刻断裂。流译把这条链路拆成两条独立的时间线：

```
滚动线（每帧 / 24 fps 采样）:  帧差测速 → 预测 → 已渲染译文层跟随（60/120 Hz）
翻译线（约 3 次/秒）:           OCR → 翻译 → 预渲染贴图 → 增量加入
```

滚动线永远不等翻译线。翻译线只负责“把新进入屏幕的内容补上”，所以滑动本身是顺的。

## 特性

- **滚动跟手**：屏幕帧差估计内容位移，Choreographer 在两次采集之间做速度外推，悬浮层按屏幕刷新率移动。
- **不拖影**：译文块是**不透明**的预渲染位图，每帧整层重绘；不使用半透明底、不使用 `LAYER_TYPE_HARDWARE`，避免 OEM 合成器留下残影。
- **UI 线程零重活**：OCR、翻译、文字排版、Bitmap 生成全部在后台单线程完成；UI 线程只做 `drawBitmap`。
- **增量翻译 + 翻译记忆**：已经见过的句子进 LRU 缓存并落盘，回看/来回滑动时几乎立即出现。
- **遮挡过滤**：识别时会排除已经渲染的译文块，避免把自己的中文译文再 OCR 一遍。
- **离线优先**：默认使用 ML Kit 端侧 OCR + 端侧翻译，截图和文字都不出手机。
- **可选云端**：兼容 OpenAI `/chat/completions` 的服务（OpenAI、DeepSeek、Moonshot、局域网中转等），只上传 OCR 文字，不上传截图。
- **悬浮球**：点“译 / 停”暂停、继续；通知栏也可控制。
- **无障碍悬浮层**：用 `TYPE_ACCESSIBILITY_OVERLAY` 创建可穿透触摸的全屏层，Android 12+ 不会被系统当成遮挡层拦截手势；**不读取页面节点内容**。

## 30 秒构建安装（不用装 Android Studio）

> **GitHub 用不了？** 直接跳过本节：
> - 用国内 Gitee 云打包（完全不占用你的电脑）：[docs/GITEE_BUILD.md](docs/GITEE_BUILD.md)
> - 或在自己电脑上双击一键构建：[本地构建](#本地构建)

这是最省事的方式，适合只想拿 APK 的人：

1. 注册/登录 GitHub。
2. 把本仓库 Fork 到你自己的账号（右上角 **Fork**）。
3. 打开你 Fork 后的仓库 → 顶部 **Actions** → 左侧 **Build APK**。
4. 点 **Run workflow** → 分支选 `main` → **Run workflow**。
5. 等 2~5 分钟，进入这次运行，页面底部 **Artifacts** 下载 `flowtranslate-debug-apk.zip`。
6. 解压得到 `app-debug.apk`，发到手机安装（需要允许“安装未知应用”）。

> Fork 后如果 Actions 页面提示需要启用，点绿色按钮启用即可。仓库自带的 workflow 在 push 时也会自动构建。

详细到每一步的 GitHub 操作（含命令行）见 **[docs/GITHUB.md](docs/GITHUB.md)**。

## 本地构建

不用 GitHub 也能在你自己的 Windows 电脑上直接编译出 APK，**完整教程见 [docs/LOCAL_BUILD.md](docs/LOCAL_BUILD.md)**。

**什么都不用懂的最简方式：解压项目后，双击 `一键构建APK.bat`。** 脚本会自动下载 Java（华为云镜像）、安卓 SDK（腾讯云镜像）、Gradle（腾讯/华为镜像）并编译，最后自动弹出 APK 所在文件夹。

```bash
# 或者命令行手动跑：
powershell -ExecutionPolicy Bypass -File .\scripts\build-all.ps1
```

APK 输出：

```
app/build/outputs/apk/debug/app-debug.apk
```

**电脑跑不动脚本？** 用国内 Gitee 云打包，完全不占用你的电脑：[docs/GITEE_BUILD.md](docs/GITEE_BUILD.md)。

也可以装 Android Studio（图形界面）后直接打开项目构建；项目已把依赖仓库切换为阿里云镜像。

## 手机上怎么用

1. 安装 APK，打开「流译」。
2. 点 **开启无障碍服务**，在系统设置里找到「流译」并开启。
   - Android 13+ 侧载应用如果开关是灰的：进入「应用信息 → 流译 → 右上角 ⋮ → 允许受限设置」，再回来开启。
3. 点 **开始翻译**，系统弹出录屏授权，点 **允许**。
4. 回到你要读的 App（小说、漫画、游戏、浏览器），正常上下滑动。
5. 屏幕右侧会出现「译」悬浮球：
   - 点一下暂停，球变成「停」；
   - 再点一下继续；
   - 通知栏里也可以暂停/停止。

首次使用离线模式会下载语言包（中文/英文/日文/韩文按你选的原文语言），需要网络；下载完成后可离线使用。

## 为什么滚动不卡、不拖影

这部分是项目的核心，详细推导见 **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)**。简单说：

1. **双时间线**：滚动跟手由采集帧驱动，译文跟随由 Choreographer 驱动；OCR/翻译慢不会阻塞画面。
2. **运动预测**：两次采集之间用最近速度外推，最多预测 60 ms；测到停止后快速吸附，避免“飘”。
3. **贴图预渲染**：每个译文块只排版一次，生成一张不透明 Bitmap；`onDraw` 里只有几十次 `drawBitmap`。
4. **不做逐帧布局**：不在 UI 线程创建 View、改 LayoutParams、测量文字。
5. **无半透明层**：半透明会让原文透出来，视觉上就是“重影”；这里用采样背景色的实心块。
6. **无硬件层**：整层每帧重绘，避免缓存层在移动时产生拖影。
7. **反馈隔离**：测速时把已经渲染的译文块区域遮掉，否则悬浮层会“追着自己”造成漂移。
8. **识别节流**：同一时刻只允许一个 OCR 任务，过期帧直接丢弃；翻译结果复用缓存。

## 真实边界

这部分很重要，避免不切实际的预期：

- **已经翻译过的内容**在滚动中紧跟手指；**第一次进入屏幕的新文字**仍需一次 OCR + 翻译，通常 300 ms~1 s 后覆盖。这是端侧 OCR/翻译的物理成本，无法做到“零延迟翻译从未见过的文字”。
- 滚动极快时，新文字会先保留原文，停下或减速后迅速补齐；已经翻译的区域不会错位。
- 银行、支付、DRM 视频等使用 `FLAG_SECURE` 的页面，MediaProjection 只能拿到黑屏，无法翻译。这是 Android 安全机制，不是 bug。
- 不支持 iOS / Windows / macOS 的跨应用悬浮层；本项目只做 Android。
- 部分游戏/阅读器用自绘 Surface，帧差仍然可用；但极低对比度或大面积纯色背景时，运动估计可能失准，表现为译文偶尔滞后，停止后会自动校正。
- 发热和耗电会高于普通阅读 App；长文本阅读建议插电或使用省电模式（见调参）。

## 翻译引擎

### 设备离线（默认）

- OCR：ML Kit Text Recognition v2，按原文语言选择 Latin / Chinese / Japanese / Korean 模型。
- 翻译：ML Kit On-Device Translation。首次使用某语言对时下载模型，之后离线。
- 优点：隐私、无 API 费用；缺点：长句和上下文质量一般。

### 云端 API（可选）

在设置里选「云端 API」，填写：

| 字段 | 示例 |
| --- | --- |
| API 地址 | `https://api.openai.com/v1` |
| API Key | 你的 key |
| 模型 | `gpt-4o-mini` |

兼容任何 `POST {base}/chat/completions` 的服务，例如：

- OpenAI：`https://api.openai.com/v1` + `gpt-4o-mini`
- DeepSeek：`https://api.deepseek.com/v1` + `deepseek-chat`
- Moonshot：`https://api.moonshot.cn/v1` + `moonshot-v1-8k`
- 局域网中转：`http://192.168.x.x:端口/v1`（注意：本项目默认禁止明文 HTTP，需要改成 HTTPS 或在 `AndroidManifest.xml` 里显式开启 `usesCleartextTraffic`）

云端模式只发送 OCR 后的**文字**，不会上传截图。API Key 只保存在本机 SharedPreferences，不会写入仓库。

## 调参

所有性能参数集中在 [`app/src/main/java/com/liuyi/flowtranslate/Tuning.kt`](app/src/main/java/com/liuyi/flowtranslate/Tuning.kt)：

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| `CAPTURE_SCALE` | 0.68 | 采集分辨率比例；越低越省电、OCR 越糊 |
| `CAPTURE_MAX_LONG_SIDE` | 1600 | 采集长边上限 |
| `TARGET_FPS` | 24 | 运动估计采样帧率 |
| `OCR_INTERVAL_MS` | 300 | OCR 最小间隔；越小越实时、越热 |
| `MAX_PREDICTION_SEC` | 0.06 | 运动外推上限；越高越跟手、停车时越容易过冲 |
| `MAX_BLOCKS` | 120 | 同时保留的译文块上限 |

低端机建议：`TARGET_FPS = 18`、`OCR_INTERVAL_MS = 400`、`CAPTURE_SCALE = 0.58`。
旗舰机建议：`TARGET_FPS = 30`、`OCR_INTERVAL_MS = 240`。

## 项目结构

```
app/src/main/java/com/liuyi/flowtranslate/
├── MainActivity.kt                  # 权限、语言/引擎设置、启动入口
├── Tuning.kt                        # 性能参数
├── capture/
│   └── ScreenCapture.kt             # MediaProjection + ImageReader + 帧节流
├── vision/
│   └── ScrollEstimator.kt           # 帧差测速、遮挡掩码、亚像素位移
├── ocr/
│   ├── OcrEngine.kt                 # ML Kit 文本识别
│   └── OcrModels.kt                 # 行分组、段落合并
├── translate/
│   ├── Translator.kt                # 翻译接口
│   ├── MlKitTranslator.kt           # 端侧翻译
│   ├── CloudTranslator.kt           # OpenAI-compatible 云端
│   └── TranslationMemory.kt         # LRU + 落盘翻译记忆
├── render/
│   ├── ColorSampler.kt              # 采样原背景色/前景色
│   ├── PatchRenderer.kt             # 译文预渲染成不透明贴图
│   ├── RenderBlock.kt               # 锚定内容的译文块
│   ├── BlockStore.kt                # 线程安全块存储
│   └── TranslationOverlayView.kt    # 只做 drawBitmap 的悬浮层
├── overlay/
│   ├── OverlayHost.kt               # 无障碍服务 ↔ 采集服务桥
│   ├── OverlayController.kt         # WindowManager + Choreographer 运动驱动
│   └── ControlBubble.kt             # 可拖动暂停球
├── service/
│   ├── FlowAccessibilityService.kt  # TYPE_ACCESSIBILITY_OVERLAY 宿主
│   └── TranslationService.kt        # 前台服务、录屏生命周期、通知
└── pipeline/
    └── TranslationPipeline.kt       # 采集 → 测速 → OCR → 翻译 → 渲染 编排
```

## 隐私与权限

- **无障碍服务**：只用于创建悬浮层，`canRetrieveWindowContent="false"`，不读取页面节点。
- **屏幕录制**：系统 `MediaProjection` 授权，只用于本地帧分析和 OCR。
- **网络**：离线模式不联网；云端模式只发送文字。
- **存储**：翻译记忆保存在应用私有目录，卸载即删除；API Key 保存在应用私有 SharedPreferences。
- 不要在密码、银行、身份证等敏感页面使用屏幕翻译类工具。

## 常见问题

**Q: 开启无障碍后，系统说“此服务可以读取屏幕内容”？**
A: 这是 Android 对无障碍服务的统一提示。本项目配置为不读取节点内容；真正的画面来自你单独授权的录屏。

**Q: 开始后悬浮层没出现？**
A: 先确认无障碍服务真的在运行（回 App 看按钮是否显示“已开启”），再确认录屏授权成功。部分 OEM 需要在最近任务里锁定 App，避免后台被杀。

**Q: 译文位置整体偏移（例如状态栏高度）？**
A: 本项目用 `FLAG_LAYOUT_IN_SCREEN` + `fitInsetsTypes=0` 对齐全屏坐标。若你的机型仍偏移，可在 `OverlayController.buildParams()` 里给 `params.y` 加一个状态栏高度补偿，或提 issue 附机型/系统版本。

**Q: 滑动时译文有一点点跟不上？**
A: 这是“新文字还没翻译”而不是位置漂移。已翻译块的位置由帧差驱动；如果整层都慢半拍，尝试提高 `TARGET_FPS` 到 30。

**Q: 为什么不用普通悬浮窗（SYSTEM_ALERT_WINDOW）？**
A: Android 12+ 会把全屏、不透明的普通悬浮窗视为“不可信遮挡”，可能拦截下层 App 的触摸。`TYPE_ACCESSIBILITY_OVERLAY` 是系统信任的无障碍层，才能既全屏显示又不挡滑动。

**Q: 能翻译漫画气泡里的竖排日文吗？**
A: 当前按水平行分组，竖排支持有限。后续可以针对竖排单独加分组策略。

## GitHub 建仓库教程

完整步骤（含 Git 安装、PAT 认证、Actions 下载 APK、打 tag 发 Release、常见报错）见：

**[docs/GITHUB.md](docs/GITHUB.md)**

最短版本：

```bash
cd flowtranslate
git init -b main
git add .
git commit -m "feat: real-time scroll screen translator"
git remote add origin https://github.com/<你的用户名>/flowtranslate.git
git push -u origin main
```

然后打开 GitHub 仓库 → **Actions** → **Build APK** → 下载 Artifact。

## License

MIT。见 [LICENSE](LICENSE)。

---

如果这个项目帮你把外文读顺了，欢迎 Star；有真机兼容性问题，附上机型、Android 版本、录屏/无障碍开关状态提 Issue。
