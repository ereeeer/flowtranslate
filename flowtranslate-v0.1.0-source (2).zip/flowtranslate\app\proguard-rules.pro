# ML Kit uses reflection internally; keep its public entry points.
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**

# Keep the accessibility service entry point.
-keep class com.liuyi.flowtranslate.service.FlowAccessibilityService { *; }
-keep class com.liuyi.flowtranslate.service.TranslationService { *; }
