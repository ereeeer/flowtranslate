package com.liuyi.flowtranslate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.liuyi.flowtranslate.data.Prefs
import com.liuyi.flowtranslate.data.RuntimeState
import com.liuyi.flowtranslate.data.TranslationProvider
import com.liuyi.flowtranslate.databinding.ActivityMainBinding
import com.liuyi.flowtranslate.service.FlowAccessibilityService
import com.liuyi.flowtranslate.service.TranslationService
import com.liuyi.flowtranslate.translate.SourceProfile
import com.liuyi.flowtranslate.translate.TargetLanguage
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: Prefs

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            try {
                TranslationService.start(this, result.resultCode, data)
                toast(getString(R.string.toast_started))
            } catch (_: Throwable) {
                toast(getString(R.string.toast_service_start_failed))
            }
        } else {
            toast(getString(R.string.toast_projection_denied))
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        launchProjection()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = Prefs(this)

        setupLanguages()
        setupProvider()
        setupCloudFields()
        setupActions()
        observeRuntimeState()
    }

    override fun onResume() {
        super.onResume()
        updateAccessibilityUi()
    }

    private fun setupLanguages() {
        val sources = SourceProfile.values()
        val sourceLabels = sources.map { it.label }
        binding.sourceInput.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_list_item_1, sourceLabels)
        )
        binding.sourceInput.setText(prefs.sourceProfile.label, false)
        binding.sourceInput.setOnItemClickListener { _, _, position, _ ->
            prefs.sourceProfile = sources[position]
            binding.sourceInput.setText(sources[position].label, false)
        }

        val targets = TargetLanguage.values()
        val targetLabels = targets.map { it.label }
        binding.targetInput.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_list_item_1, targetLabels)
        )
        binding.targetInput.setText(prefs.targetLanguage.label, false)
        binding.targetInput.setOnItemClickListener { _, _, position, _ ->
            prefs.targetLanguage = targets[position]
            binding.targetInput.setText(targets[position].label, false)
        }
    }

    private fun setupProvider() {
        binding.providerGroup.check(
            if (prefs.provider == TranslationProvider.CLOUD) {
                R.id.providerCloud
            } else {
                R.id.providerDevice
            }
        )
        updateProviderUi(prefs.provider)
        binding.providerGroup.setOnCheckedChangeListener { _, checkedId ->
            val provider = if (checkedId == R.id.providerCloud) {
                TranslationProvider.CLOUD
            } else {
                TranslationProvider.ON_DEVICE
            }
            prefs.provider = provider
            updateProviderUi(provider)
        }
    }

    private fun updateProviderUi(provider: TranslationProvider) {
        val cloud = provider == TranslationProvider.CLOUD
        binding.cloudGroup.visibility = if (cloud) android.view.View.VISIBLE else android.view.View.GONE
        binding.providerHint.text = getString(
            if (cloud) R.string.provider_cloud_hint else R.string.provider_device_hint
        )
        binding.privacyText.text = getString(
            if (cloud) R.string.privacy_cloud else R.string.privacy_on_device
        )
    }

    private fun setupCloudFields() {
        binding.endpointInput.setText(prefs.apiBase)
        binding.apiKeyInput.setText(prefs.apiKey)
        binding.modelInput.setText(prefs.model)
        binding.endpointInput.doAfterTextChanged { prefs.apiBase = it?.toString().orEmpty() }
        binding.apiKeyInput.doAfterTextChanged { prefs.apiKey = it?.toString().orEmpty() }
        binding.modelInput.doAfterTextChanged { prefs.model = it?.toString().orEmpty() }
    }

    private fun setupActions() {
        binding.accessibilityButton.setOnClickListener {
            toast(getString(R.string.toast_accessibility_settings))
            runCatching { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        binding.startButton.setOnClickListener { startClicked() }
        binding.stopButton.setOnClickListener { TranslationService.stop(this) }
    }

    private fun startClicked() {
        if (RuntimeState.running.value) return
        if (!FlowAccessibilityService.isRunning) {
            toast(getString(R.string.accessibility_required))
            toast(getString(R.string.toast_accessibility_settings))
            runCatching { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            return
        }
        if (prefs.provider == TranslationProvider.CLOUD && !prefs.isCloudConfigured()) {
            toast(getString(R.string.toast_cloud_incomplete))
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        launchProjection()
    }

    private fun launchProjection() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        try {
            projectionLauncher.launch(manager.createScreenCaptureIntent())
        } catch (_: Throwable) {
            toast(getString(R.string.toast_service_start_failed))
        }
    }

    private fun updateAccessibilityUi() {
        val enabled = FlowAccessibilityService.isRunning
        binding.accessibilityButton.text = getString(
            if (enabled) R.string.accessibility_enabled else R.string.accessibility_button
        )
        binding.accessibilityButton.isEnabled = !enabled
    }

    private fun observeRuntimeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    RuntimeState.running.collect { running ->
                        binding.startButton.isEnabled = !running
                        binding.startButton.text = getString(
                            if (running) R.string.running_button else R.string.start_translation
                        )
                        binding.stopButton.visibility =
                            if (running) android.view.View.VISIBLE else android.view.View.GONE
                    }
                }
                launch {
                    RuntimeState.status.collect { status ->
                        binding.statusText.text = status
                    }
                }
                launch {
                    RuntimeState.paused.collect { paused ->
                        val running = RuntimeState.running.value
                        binding.statusDot.setTextColor(
                            when {
                                paused -> ContextCompat.getColor(
                                    this@MainActivity,
                                    R.color.status_amber
                                )

                                running -> ContextCompat.getColor(
                                    this@MainActivity,
                                    R.color.status_green
                                )

                                else -> ContextCompat.getColor(
                                    this@MainActivity,
                                    R.color.status_amber
                                )
                            }
                        )
                    }
                }
                launch {
                    RuntimeState.translatedCount.collect { count ->
                        binding.countText.text = getString(R.string.count_format, count)
                    }
                }
            }
        }
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}
