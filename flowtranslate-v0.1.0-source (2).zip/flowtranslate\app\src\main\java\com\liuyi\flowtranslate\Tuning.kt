package com.liuyi.flowtranslate

/**
 * Central performance knobs. Keep the hot path allocation-free and these values sane.
 *
 * If you see OCR pressure on a low-end phone: lower [TARGET_FPS] to 18 and raise
 * [OCR_INTERVAL_MS] to 400. If text feels too coarse while scrolling, raise
 * [TARGET_FPS] to 30 first, not the OCR rate.
 */
object Tuning {
    /** Screen is captured at this fraction of the display resolution, capped by [CAPTURE_MAX_LONG_SIDE]. */
    const val CAPTURE_SCALE = 0.68f

    /** 1600 px on the long edge is enough for ML Kit on normal phone text, at a fraction of 4K cost. */
    const val CAPTURE_MAX_LONG_SIDE = 1600

    /** Frames used for motion tracking. Overlay itself renders at display refresh rate. */
    const val TARGET_FPS = 24

    /** At most one OCR job is in flight. 300 ms is ~3.3 full-screen OCR passes per second. */
    const val OCR_INTERVAL_MS = 300L

    /** Do not extrapolate motion further than this; limits overshoot when the finger stops. */
    const val MAX_PREDICTION_SEC = 0.06f

    /** Keep the overlay draw list bounded. */
    const val MAX_BLOCKS = 120
}
