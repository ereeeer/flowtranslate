package com.liuyi.flowtranslate.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import com.liuyi.flowtranslate.Tuning
import com.liuyi.flowtranslate.model.ScreenMetrics
import kotlin.math.max
import kotlin.math.min

/**
 * MediaProjection -> ImageReader -> reusable Bitmap.
 *
 * Only one frame is processed at a time on this HandlerThread. Older images are
 * discarded with acquireLatestImage(), and frames beyond [Tuning.TARGET_FPS] are
 * dropped before the expensive conversion. No allocation happens per frame after
 * the first one (except a tiny Rect/Canvas wrapper, kept as fields).
 */
class ScreenCapture(
    context: Context,
    private val projection: MediaProjection,
    private val onFrame: (Bitmap, Long) -> Unit,
    private val onError: (Throwable) -> Unit
) {
    private val thread = HandlerThread("flow-capture").apply { start() }
    private val handler = Handler(thread.looper)
    private val frameIntervalNs = 1_000_000_000L / Tuning.TARGET_FPS

    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var scratch: Bitmap? = null
    private var scratchCanvas: Canvas? = null
    private var padded: Bitmap? = null
    private var width = 0
    private var height = 0
    private var densityDpi = 0
    private var lastFrameAt = 0L
    private var stopped = false
    private val srcRect = Rect()
    private val dstRect = Rect()

    fun start(metrics: ScreenMetrics) {
        handler.post { startInternal(metrics) }
    }

    fun reconfigure(metrics: ScreenMetrics) {
        handler.post { reconfigureInternal(metrics) }
    }

    fun stop() {
        handler.post {
            if (stopped) return@post
            stopped = true
            reader?.setOnImageAvailableListener(null, null)
            runCatching { virtualDisplay?.release() }
            runCatching { reader?.close() }
            scratch?.recycle()
            padded?.recycle()
            scratch = null
            padded = null
            scratchCanvas = null
            virtualDisplay = null
            reader = null
            thread.quitSafely()
        }
    }

    private fun startInternal(metrics: ScreenMetrics) {
        if (stopped || virtualDisplay != null) return
        try {
            val size = computeSize(metrics)
            width = size.width
            height = size.height
            densityDpi = size.densityDpi
            val imageReader = ImageReader.newInstance(
                width,
                height,
                PixelFormat.RGBA_8888,
                2
            )
            imageReader.setOnImageAvailableListener({ onImageAvailable(it) }, handler)
            val display = projection.createVirtualDisplay(
                "flow-translate-capture",
                width,
                height,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.surface,
                null,
                handler
            )
            if (display == null) {
                imageReader.close()
                onError(IllegalStateException("无法创建屏幕采集表面"))
                return
            }
            reader = imageReader
            virtualDisplay = display
            allocateScratch()
            lastFrameAt = 0L
        } catch (t: Throwable) {
            onError(t)
        }
    }

    private fun reconfigureInternal(metrics: ScreenMetrics) {
        if (stopped) return
        val display = virtualDisplay
        if (display == null) {
            startInternal(metrics)
            return
        }
        try {
            val size = computeSize(metrics)
            val imageReader = ImageReader.newInstance(
                size.width,
                size.height,
                PixelFormat.RGBA_8888,
                2
            )
            imageReader.setOnImageAvailableListener({ onImageAvailable(it) }, handler)
            display.setSurface(imageReader.surface)
            display.resize(size.width, size.height, size.densityDpi)

            width = size.width
            height = size.height
            densityDpi = size.densityDpi
            val old = reader
            reader = imageReader
            old?.setOnImageAvailableListener(null, null)
            runCatching { old?.close() }
            allocateScratch()
            lastFrameAt = 0L
        } catch (t: Throwable) {
            onError(t)
        }
    }

    private fun allocateScratch() {
        scratch?.recycle()
        padded?.recycle()
        padded = null
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bitmap.density = Bitmap.DENSITY_NONE
        scratch = bitmap
        scratchCanvas = Canvas(bitmap)
        srcRect.set(0, 0, width, height)
        dstRect.set(0, 0, width, height)
    }

    private fun onImageAvailable(imageReader: ImageReader) {
        if (stopped) {
            runCatching { imageReader.acquireLatestImage()?.close() }
            return
        }
        val image: Image = try {
            imageReader.acquireLatestImage()
        } catch (t: Throwable) {
            onError(t)
            return
        } ?: return

        try {
            val timestamp = if (image.timestamp > 0L) image.timestamp else SystemClock.elapsedRealtimeNanos()
            if (lastFrameAt != 0L && timestamp - lastFrameAt < frameIntervalNs) return
            lastFrameAt = timestamp

            val plane = image.planes.getOrNull(0) ?: return
            val pixelStride = plane.pixelStride
            if (pixelStride != 4) return
            val paddedWidth = plane.rowStride / pixelStride
            if (paddedWidth < width || height != image.height) return

            val paddedBitmap = ensurePadded(paddedWidth)
            val buffer = plane.buffer
            buffer.rewind()
            paddedBitmap.copyPixelsFromBuffer(buffer)

            val target = scratch ?: return
            scratchCanvas?.drawBitmap(paddedBitmap, srcRect, dstRect, null)
            onFrame(target, timestamp)
        } catch (t: Throwable) {
            onError(t)
        } finally {
            image.close()
        }
    }

    private fun ensurePadded(paddedWidth: Int): Bitmap {
        val current = padded
        if (current != null && current.width == paddedWidth && current.height == height) {
            return current
        }
        current?.recycle()
        val bitmap = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        bitmap.density = Bitmap.DENSITY_NONE
        padded = bitmap
        return bitmap
    }

    private fun computeSize(metrics: ScreenMetrics): Size {
        val longSide = max(metrics.width, metrics.height)
        if (longSide <= 0) throw IllegalArgumentException("屏幕尺寸无效")
        val scale = min(
            Tuning.CAPTURE_SCALE,
            Tuning.CAPTURE_MAX_LONG_SIDE.toFloat() / longSide
        )
        val w = ((metrics.width * scale).toInt() / 2 * 2).coerceAtLeast(2)
        val h = ((metrics.height * scale).toInt() / 2 * 2).coerceAtLeast(2)
        val dpi = (metrics.densityDpi * scale).toInt().coerceAtLeast(120)
        return Size(w, h, dpi)
    }

    private data class Size(val width: Int, val height: Int, val densityDpi: Int)
}
