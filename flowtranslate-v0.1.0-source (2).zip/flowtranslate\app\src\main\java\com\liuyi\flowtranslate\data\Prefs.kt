package com.liuyi.flowtranslate.data

import android.content.Context
import com.liuyi.flowtranslate.translate.SourceProfile
import com.liuyi.flowtranslate.translate.TargetLanguage

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    var sourceProfile: SourceProfile
        get() = SourceProfile.fromId(sp.getString(KEY_SOURCE, SourceProfile.ENGLISH.id))
        set(value) = sp.edit().putString(KEY_SOURCE, value.id).apply()

    var targetLanguage: TargetLanguage
        get() = TargetLanguage.fromId(sp.getString(KEY_TARGET, null))
        set(value) = sp.edit().putString(KEY_TARGET, value.id).apply()

    var provider: TranslationProvider
        get() = TranslationProvider.fromId(sp.getString(KEY_PROVIDER, null))
        set(value) = sp.edit().putString(KEY_PROVIDER, value.id).apply()

    var apiBase: String
        get() = sp.getString(KEY_API_BASE, DEFAULT_API_BASE)?.trim().orEmpty().ifEmpty { DEFAULT_API_BASE }
        set(value) = sp.edit().putString(KEY_API_BASE, value.trim()).apply()

    var apiKey: String
        get() = sp.getString(KEY_API_KEY, "").orEmpty()
        set(value) = sp.edit().putString(KEY_API_KEY, value.trim()).apply()

    var model: String
        get() = sp.getString(KEY_MODEL, DEFAULT_MODEL)?.trim().orEmpty().ifEmpty { DEFAULT_MODEL }
        set(value) = sp.edit().putString(KEY_MODEL, value.trim()).apply()

    var bubbleEnabled: Boolean
        get() = sp.getBoolean(KEY_BUBBLE, true)
        set(value) = sp.edit().putBoolean(KEY_BUBBLE, value).apply()

    fun isCloudConfigured(): Boolean = apiBase.isNotBlank() && apiKey.isNotBlank()

    companion object {
        private const val NAME = "flow_prefs"
        private const val KEY_SOURCE = "source_profile"
        private const val KEY_TARGET = "target_language"
        private const val KEY_PROVIDER = "provider"
        private const val KEY_API_BASE = "api_base"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_MODEL = "model"
        private const val KEY_BUBBLE = "bubble_enabled"

        const val DEFAULT_API_BASE = "https://api.openai.com/v1"
        const val DEFAULT_MODEL = "gpt-4o-mini"
    }
}

enum class TranslationProvider(val id: String) {
    ON_DEVICE("device"),
    CLOUD("cloud");

    companion object {
        fun fromId(id: String?): TranslationProvider =
            values().firstOrNull { it.id == id } ?: ON_DEVICE
    }
}
