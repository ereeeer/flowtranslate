package com.liuyi.flowtranslate.data

import kotlinx.coroutines.flow.MutableStateFlow

/** Process-wide state for the (single) translation session. */
object RuntimeState {
    val running = MutableStateFlow(false)
    val paused = MutableStateFlow(false)
    val status = MutableStateFlow("未启动")
    val translatedCount = MutableStateFlow(0)
    val sessionId = MutableStateFlow(0L)

    fun begin() {
        sessionId.value += 1
        running.value = true
        paused.value = false
        translatedCount.value = 0
        status.value = "正在准备…"
    }

    fun end() {
        running.value = false
        paused.value = false
        translatedCount.value = 0
        status.value = "未启动"
    }
}
