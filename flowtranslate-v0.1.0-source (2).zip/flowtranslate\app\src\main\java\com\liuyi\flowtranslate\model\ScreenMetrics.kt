package com.liuyi.flowtranslate.model

import android.content.Context
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

/** Full-display geometry, shared by MediaProjection, the overlay and the OCR mapper. */
data class ScreenMetrics(
    val width: Int,
    val height: Int,
    val densityDpi: Int,
    val density: Float
) {
    companion object {
        fun from(context: Context): ScreenMetrics {
            val wm = context.getSystemService(WindowManager::class.java)
            val bounds: Rect = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                wm.maximumWindowMetrics.bounds
            } else {
                @Suppress("DEPRECATION")
                val display = wm.defaultDisplay
                val real = DisplayMetrics()
                @Suppress("DEPRECATION")
                display.getRealMetrics(real)
                Rect(0, 0, real.widthPixels, real.heightPixels)
            }
            val dm = context.resources.displayMetrics
            val width = bounds.width().takeIf { it > 0 } ?: dm.widthPixels
            val height = bounds.height().takeIf { it > 0 } ?: dm.heightPixels
            return ScreenMetrics(
                width = width,
                height = height,
                densityDpi = dm.densityDpi,
                density = dm.density
            )
        }
    }
}
