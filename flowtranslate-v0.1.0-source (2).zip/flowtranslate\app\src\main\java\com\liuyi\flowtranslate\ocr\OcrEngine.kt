package com.liuyi.flowtranslate.ocr

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.liuyi.flowtranslate.translate.RecognizerKind
import com.liuyi.flowtranslate.translate.SourceProfile
import kotlinx.coroutines.tasks.await

class OcrEngine(profile: SourceProfile) {
    private val recognizer: TextRecognizer = when (profile.recognizer) {
        RecognizerKind.CHINESE ->
            TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())

        RecognizerKind.JAPANESE ->
            TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())

        RecognizerKind.KOREAN ->
            TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())

        RecognizerKind.LATIN ->
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun recognize(bitmap: Bitmap): Text {
        val image = InputImage.fromBitmap(bitmap, 0)
        return recognizer.process(image).await()
    }

    fun close() {
        recognizer.close()
    }
}
