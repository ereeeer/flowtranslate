package com.liuyi.flowtranslate.ocr

import android.graphics.RectF
import com.google.mlkit.vision.text.Text
import com.liuyi.flowtranslate.util.TextTools

/** A paragraph-like group of OCR lines. Coordinates are in capture-bitmap pixels. */
data class OcrGroup(
    val text: String,
    val rect: RectF,
    val lineCount: Int,
    val lineHeight: Float
)

object OcrParser {
    private data class LineBox(
        val text: String,
        val rect: RectF
    )

    fun parse(result: Text): List<OcrGroup> {
        val lines = ArrayList<LineBox>()
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val box = line.boundingBox ?: continue
                val text = line.text.trim()
                if (text.isEmpty() || !TextTools.hasUsefulText(text)) continue
                if (box.width() < 4 || box.height() < 4) continue
                lines.add(LineBox(text, RectF(box)))
            }
        }
        if (lines.isEmpty()) return emptyList()
        lines.sortWith(compareBy({ it.rect.top }, { it.rect.left }))

        val groups = ArrayList<MutableList<LineBox>>()
        for (line in lines) {
            val current = groups.lastOrNull()
            if (current != null && canJoin(current.last(), line)) {
                current.add(line)
            } else {
                groups.add(mutableListOf(line))
            }
        }

        val resultGroups = ArrayList<OcrGroup>(groups.size)
        for (group in groups) {
            val union = RectF(group.first().rect)
            for (i in 1 until group.size) union.union(group[i].rect)
            val heights = group.map { it.rect.height() }.sorted()
            val medianHeight = heights[heights.size / 2]
            val text = group.joinToString(" ") { it.text }
            if (text.length > 800) continue
            resultGroups.add(
                OcrGroup(
                    text = text,
                    rect = union,
                    lineCount = group.size,
                    lineHeight = medianHeight
                )
            )
        }
        return resultGroups
    }

    private fun canJoin(a: LineBox, b: LineBox): Boolean {
        val lineHeight = maxOf(a.rect.height(), b.rect.height())
        if (lineHeight <= 1f) return false
        val gap = b.rect.top - a.rect.bottom
        if (gap > lineHeight * 0.7f || gap < -lineHeight * 0.25f) return false

        val overlap = minOf(a.rect.right, b.rect.right) - maxOf(a.rect.left, b.rect.left)
        val narrower = minOf(a.rect.width(), b.rect.width())
        if (narrower <= 1f || overlap / narrower < 0.30f) return false

        val heightRatio = a.rect.height() / b.rect.height()
        return heightRatio in 0.55f..1.8f
    }
}
