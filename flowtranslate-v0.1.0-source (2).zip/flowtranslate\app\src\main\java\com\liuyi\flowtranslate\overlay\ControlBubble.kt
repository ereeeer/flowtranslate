package com.liuyi.flowtranslate.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import com.liuyi.flowtranslate.model.ScreenMetrics
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Tiny draggable pause/resume bubble. It is the only touchable window we own;
 * everything else is FLAG_NOT_TOUCHABLE so the reading app keeps receiving gestures.
 */
class ControlBubble(
    context: Context,
    private val windowType: Int,
    private val onTap: () -> Unit
) {
    private val appContext = context
    private val windowManager = context.getSystemService(WindowManager::class.java)
    private val size = dp(50f)
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val view = TextView(context).apply {
        gravity = Gravity.CENTER
        textSize = 17f
        setTextColor(Color.WHITE)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        elevation = dp(8f).toFloat()
        alpha = 0.92f
        isClickable = true
        contentDescription = "暂停或继续翻译"
        background = backgroundDrawable(false)
    }
    private val params = WindowManager.LayoutParams(
        size,
        size,
        windowType,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 0
        y = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Same full-display coordinate space as the translation overlay, so
            // bounds() lines up with the MediaProjection frame.
            fitInsetsTypes = 0
        }
    }

    private var attached = false
    private var screenWidth = 0
    private var screenHeight = 0
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    init {
        view.text = "译"
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    params.x = (startX + dx).roundToInt().coerceIn(0, maxX())
                    params.y = (startY + dy).roundToInt().coerceIn(0, maxY())
                    if (attached) {
                        runCatching { windowManager.updateViewLayout(view, params) }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap()
                    true
                }

                MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
    }

    fun show(metrics: ScreenMetrics) {
        updateMetrics(metrics)
        if (!attached) {
            params.x = (metrics.width - size - dp(8f)).coerceAtLeast(0)
            params.y = (metrics.height * 0.32f).roundToInt().coerceIn(0, maxY())
            attached = runCatching { windowManager.addView(view, params) }.isSuccess
        }
        view.visibility = View.VISIBLE
    }

    fun hide() {
        if (!attached) return
        runCatching { windowManager.removeView(view) }
        attached = false
    }

    fun updateMetrics(metrics: ScreenMetrics) {
        screenWidth = metrics.width
        screenHeight = metrics.height
        if (attached) {
            params.x = params.x.coerceIn(0, maxX())
            params.y = params.y.coerceIn(0, maxY())
            runCatching { windowManager.updateViewLayout(view, params) }
        }
    }

    fun setPaused(value: Boolean) {
        view.text = if (value) "停" else "译"
        view.background = backgroundDrawable(value)
        view.contentDescription = if (value) "继续翻译" else "暂停翻译"
    }

    fun bounds(): Rect = Rect(params.x, params.y, params.x + size, params.y + size)

    fun isVisible(): Boolean = attached && view.visibility == View.VISIBLE

    private fun maxX(): Int = (screenWidth - size).coerceAtLeast(0)

    private fun maxY(): Int = (screenHeight - size).coerceAtLeast(0)

    private fun backgroundDrawable(isPaused: Boolean): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (isPaused) 0xCC5F6368.toInt() else 0xCC1F6FEB.toInt())
            setStroke(dp(1.2f), 0x66FFFFFF)
        }

    private fun dp(value: Float): Int =
        (value * appContext.resources.displayMetrics.density).roundToInt().coerceAtLeast(1)
}
