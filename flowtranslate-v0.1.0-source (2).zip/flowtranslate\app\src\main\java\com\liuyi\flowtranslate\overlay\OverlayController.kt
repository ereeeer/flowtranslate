package com.liuyi.flowtranslate.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import com.liuyi.flowtranslate.Tuning
import com.liuyi.flowtranslate.model.ScreenMetrics
import com.liuyi.flowtranslate.render.BlockStore
import com.liuyi.flowtranslate.render.PatchRenderer
import com.liuyi.flowtranslate.render.RenderBlock
import com.liuyi.flowtranslate.render.TranslationOverlayView
import kotlin.math.abs

/**
 * Owns the trusted accessibility overlay, the control bubble and the 60/120 Hz
 * motion driver. Capture/OCR threads only enqueue work here; all WindowManager
 * and Choreographer access happens on the main looper.
 */
class OverlayController(
    context: Context,
    private val windowType: Int,
    initialMetrics: ScreenMetrics,
    showBubble: Boolean
) {
    private val windowManager = context.getSystemService(WindowManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private val choreographer = Choreographer.getInstance()
    private val view = TranslationOverlayView(context)
    private val store = BlockStore()
    private val renderer = PatchRenderer(initialMetrics.density, initialMetrics.densityDpi)

    private var toggleCallback: (() -> Unit)? = null

    private val bubble = ControlBubble(context, windowType) { toggleCallback?.invoke() }

    @Volatile
    private var metrics: ScreenMetrics = initialMetrics

    private var params: WindowManager.LayoutParams = buildParams(initialMetrics)
    private var attached = false
    private var paused = false
    private var bubbleEnabled = showBubble

    @Volatile
    private var baseX = 0f

    @Volatile
    private var baseY = 0f

    @Volatile
    private var velocityX = 0f

    @Volatile
    private var velocityY = 0f

    @Volatile
    private var renderScrollX = 0f

    @Volatile
    private var renderScrollY = 0f

    @Volatile
    private var publishGeneration = 0

    private var measureTs = 0L
    private var lastPrune = 0L
    private var animating = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!animating || paused) {
                animating = false
                return
            }
            val age = ((frameTimeNanos - measureTs).coerceAtLeast(0L) / 1_000_000_000f)
                .coerceAtMost(Tuning.MAX_PREDICTION_SEC)
            val scrollX = baseX + velocityX * age
            val scrollY = baseY + velocityY * age
            renderScrollX = scrollX
            renderScrollY = scrollY
            view.setScroll(scrollX, scrollY)

            if (frameTimeNanos - lastPrune > 250_000_000L) {
                lastPrune = frameTimeNanos
                if (store.prune(scrollX, scrollY, metrics.width, metrics.height)) publish()
            }

            if (frameTimeNanos - measureTs > 250_000_000L) {
                animating = false
                // The finger stopped; prediction must not leave patches floating.
                renderScrollX = baseX
                renderScrollY = baseY
                view.setScroll(baseX, baseY)
            } else {
                choreographer.postFrameCallback(this)
            }
        }
    }

    fun show(metrics: ScreenMetrics, onToggle: () -> Unit, showBubble: Boolean): Boolean {
        toggleCallback = onToggle
        bubbleEnabled = showBubble
        updateMetrics(metrics)
        if (!attached) {
            attached = runCatching { windowManager.addView(view, params) }.isSuccess
        }
        if (!attached) return false
        view.visibility = android.view.View.VISIBLE
        paused = false
        bubble.setPaused(false)
        if (bubbleEnabled) bubble.show(metrics) else bubble.hide()
        publish()
        return true
    }

    fun hide() {
        animating = false
        choreographer.removeFrameCallback(frameCallback)
        bubble.hide()
        if (attached) {
            runCatching { windowManager.removeView(view) }
            attached = false
        }
        store.clear()
        resetView()
        paused = false
    }

    fun setPaused(value: Boolean) {
        paused = value
        bubble.setPaused(value)
        if (value) {
            animating = false
            choreographer.removeFrameCallback(frameCallback)
            store.clear()
            resetView()
            view.visibility = android.view.View.INVISIBLE
        } else {
            view.visibility = android.view.View.VISIBLE
            publish()
        }
    }

    fun isPaused(): Boolean = paused

    fun setBubbleEnabled(enabled: Boolean) {
        bubbleEnabled = enabled
        if (enabled && attached) bubble.show(metrics) else bubble.hide()
    }

    fun updateMetrics(newMetrics: ScreenMetrics) {
        metrics = newMetrics
        params = buildParams(newMetrics)
        if (attached) {
            runCatching { windowManager.updateViewLayout(view, params) }
        }
        bubble.updateMetrics(newMetrics)
        if (attached && bubbleEnabled) bubble.show(newMetrics) else bubble.hide()
        animating = false
        choreographer.removeFrameCallback(frameCallback)
        store.clear()
        resetView()
        baseX = 0f
        baseY = 0f
        velocityX = 0f
        velocityY = 0f
        renderScrollX = 0f
        renderScrollY = 0f
    }

    fun addBlock(block: RenderBlock): Boolean {
        if (paused) return false
        val added = store.add(block)
        if (added) publish()
        return added
    }

    fun renderAndAdd(
        key: String,
        sourceText: String,
        translated: String,
        sourceRect: RectF,
        anchorScrollX: Float,
        anchorScrollY: Float,
        background: Int,
        textColor: Int,
        sourceLineHeight: Float,
        sourceLineCount: Int
    ): Boolean {
        if (paused || translated.isBlank()) return false
        // Skip the allocation if a covering patch for this text already exists.
        if (store.hasNear(key, sourceRect, anchorScrollX, anchorScrollY)) return false
        val current = metrics
        val rendered = renderer.render(
            text = translated,
            sourceRect = sourceRect,
            background = background,
            textColor = textColor,
            sourceLineHeight = sourceLineHeight,
            sourceLineCount = sourceLineCount,
            screenWidth = current.width,
            screenHeight = current.height
        )
        val block = RenderBlock(
            key = key,
            sourceText = sourceText,
            baseRect = rendered.coverRect,
            anchorScrollX = anchorScrollX,
            anchorScrollY = anchorScrollY,
            patch = rendered.patch
        )
        return addBlock(block)
    }

    fun clearBlocks() {
        store.clear()
        resetView()
    }

    fun onScroll(
        scrollX: Float,
        scrollY: Float,
        instantVelocityX: Float,
        instantVelocityY: Float,
        timestampNanos: Long,
        confidence: Float
    ) {
        if (paused) return
        handler.post {
            applyMotion(
                scrollX,
                scrollY,
                instantVelocityX,
                instantVelocityY,
                timestampNanos,
                confidence
            )
        }
    }

    private fun applyMotion(
        scrollX: Float,
        scrollY: Float,
        instantVelocityX: Float,
        instantVelocityY: Float,
        timestampNanos: Long,
        confidence: Float
    ) {
        if (paused) return
        baseX = scrollX
        baseY = scrollY
        if (confidence >= 0.10f) {
            velocityX = velocityX * 0.55f + instantVelocityX * 0.45f
            velocityY = velocityY * 0.55f + instantVelocityY * 0.45f
            measureTs = if (timestampNanos > 0L) timestampNanos else System.nanoTime()
            if (!animating) {
                animating = true
                choreographer.postFrameCallback(frameCallback)
            }
        } else {
            // No confident motion: decay velocity. Don't refresh measureTs so the
            // frame callback can expire on its own ~250ms after the last movement,
            // instead of spinning forever at display refresh rate.
            velocityX *= 0.35f
            velocityY *= 0.35f
            val stillMoving = velocityX > 1f || velocityX < -1f || velocityY > 1f || velocityY < -1f
            if (stillMoving && !animating) {
                animating = true
                choreographer.postFrameCallback(frameCallback)
            }
        }
    }

    fun occlusionRectsAt(scrollX: Float, scrollY: Float): List<RectF> {
        val result = ArrayList<RectF>()
        result.addAll(store.occlusionRectsAt(scrollX, scrollY, metrics.width, metrics.height))
        if (bubbleEnabled && bubble.isVisible()) {
            val rect: Rect = bubble.bounds()
            result.add(RectF(rect))
        }
        return result
    }

    /**
     * Occlusion rects at the scroll position the view actually drew last frame
     * (measured scroll + Choreographer prediction). This is what the MediaProjection
     * frame physically contains, so the motion estimator must mask exactly these.
     * Each rect is dilated by the prediction horizon to tolerate one frame of lag.
     */
    fun renderOcclusionRects(): List<RectF> {
        val horizontalPadding = abs(velocityX) * Tuning.MAX_PREDICTION_SEC + 10f
        val verticalPadding = abs(velocityY) * Tuning.MAX_PREDICTION_SEC + 10f
        val result = ArrayList<RectF>()
        for (rect in store.occlusionRectsAt(
            renderScrollX,
            renderScrollY,
            metrics.width,
            metrics.height
        )) {
            rect.inset(-horizontalPadding, -verticalPadding)
            result.add(rect)
        }
        if (bubbleEnabled && bubble.isVisible()) {
            val rect: Rect = bubble.bounds()
            result.add(RectF(rect))
        }
        return result
    }

    fun blockCount(): Int = store.count()

    private fun resetView() {
        publishGeneration++
        view.setBlocks(emptyList())
    }

    private fun publish() {
        val generation = publishGeneration
        handler.post {
            if (generation == publishGeneration) {
                view.setBlocks(store.snapshot())
            }
        }
    }

    private fun buildParams(metrics: ScreenMetrics): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            metrics.width,
            metrics.height,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Draw in full-display coordinates, including the status-bar area.
                fitInsetsTypes = 0
            }
        }
}
