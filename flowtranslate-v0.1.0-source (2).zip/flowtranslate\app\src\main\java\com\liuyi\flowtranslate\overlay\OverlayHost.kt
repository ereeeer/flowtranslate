package com.liuyi.flowtranslate.overlay

import android.view.WindowManager
import com.liuyi.flowtranslate.model.ScreenMetrics
import com.liuyi.flowtranslate.service.FlowAccessibilityService

/**
 * Bridge between the accessibility service (which is allowed to create the overlay)
 * and the foreground capture service (which owns the translation session).
 */
object OverlayHost {
    private val lock = Any()
    private var service: FlowAccessibilityService? = null
    private var controller: OverlayController? = null
    private var onSessionLost: (() -> Unit)? = null

    fun attach(accessibilityService: FlowAccessibilityService) {
        synchronized(lock) { service = accessibilityService }
    }

    fun detach() {
        val lost: (() -> Unit)?
        synchronized(lock) {
            controller?.hide()
            controller = null
            service = null
            lost = onSessionLost
            onSessionLost = null
        }
        lost?.invoke()
    }

    fun isReady(): Boolean = synchronized(lock) { service != null }

    fun show(
        metrics: ScreenMetrics,
        showBubble: Boolean,
        onToggle: () -> Unit,
        onLost: () -> Unit
    ): Boolean {
        synchronized(lock) {
            val host = service ?: return false
            val overlay = controller ?: OverlayController(
                context = host,
                windowType = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                initialMetrics = metrics,
                showBubble = showBubble
            ).also { controller = it }
            onSessionLost = onLost
            return overlay.show(metrics, onToggle, showBubble)
        }
    }

    fun hide() {
        synchronized(lock) {
            controller?.hide()
            onSessionLost = null
        }
    }

    fun controller(): OverlayController? = synchronized(lock) { controller }
}
