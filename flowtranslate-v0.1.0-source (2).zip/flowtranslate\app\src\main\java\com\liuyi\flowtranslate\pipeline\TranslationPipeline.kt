package com.liuyi.flowtranslate.pipeline

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.RectF
import android.media.projection.MediaProjection
import android.os.SystemClock
import com.liuyi.flowtranslate.Tuning
import com.liuyi.flowtranslate.capture.ScreenCapture
import com.liuyi.flowtranslate.data.Prefs
import com.liuyi.flowtranslate.data.TranslationProvider
import com.liuyi.flowtranslate.model.ScreenMetrics
import com.liuyi.flowtranslate.ocr.OcrEngine
import com.liuyi.flowtranslate.ocr.OcrParser
import com.liuyi.flowtranslate.overlay.OverlayController
import com.liuyi.flowtranslate.render.ColorSampler
import com.liuyi.flowtranslate.render.PatchColors
import com.liuyi.flowtranslate.translate.CloudTranslator
import com.liuyi.flowtranslate.translate.MlKitTranslator
import com.liuyi.flowtranslate.translate.SourceProfile
import com.liuyi.flowtranslate.translate.TargetLanguage
import com.liuyi.flowtranslate.translate.TranslationItem
import com.liuyi.flowtranslate.translate.TranslationMemory
import com.liuyi.flowtranslate.translate.Translator
import com.liuyi.flowtranslate.util.BitmapPool
import com.liuyi.flowtranslate.util.TextTools
import com.liuyi.flowtranslate.util.overlapRatio
import com.liuyi.flowtranslate.vision.ScrollEstimator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * The real-time pipeline:
 *
 *   capture thread: frame -> scroll estimator -> overlay motion (60/120 Hz driver)
 *                              \-> snapshot -> OCR (single worker)
 *   worker: OCR -> group -> cache lookup -> render patch -> overlay
 *                              \-> cloud/on-device translation -> render patch
 *
 * OCR and translation never touch the UI thread. The overlay only blits opaque,
 * pre-rendered bitmaps, which is what keeps scrolling smooth and ghost-free.
 */
class TranslationPipeline(
    context: Context,
    projection: MediaProjection,
    initialMetrics: ScreenMetrics,
    private val overlay: OverlayController,
    private val prefs: Prefs,
    private val onStatus: (String, Int) -> Unit
) {
    private val appContext = context.applicationContext
    private val workExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "flow-ocr-translate").apply { isDaemon = true }
    }
    private val dispatcher = workExecutor.asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + dispatcher)
    private val profile: SourceProfile = prefs.sourceProfile
    private val target: TargetLanguage = prefs.targetLanguage
    private val ocr = OcrEngine(profile)
    private val translator: Translator = buildTranslator()
    private val memory = TranslationMemory(appContext)
    private val estimator = ScrollEstimator()
    private val pool = BitmapPool(3)
    private val capture = ScreenCapture(appContext, projection, ::onFrame, ::onCaptureError)
    private val ocrBusy = AtomicBoolean(false)
    private val pendingKeys = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val translatedCount = AtomicInteger(0)
    private val nextId = AtomicLong(1L)

    @Volatile
    private var metrics: ScreenMetrics = initialMetrics

    @Volatile
    private var scrollX = 0f

    @Volatile
    private var scrollY = 0f

    @Volatile
    private var paused = false

    @Volatile
    private var stopped = false

    @Volatile
    private var epoch = 0

    private var lastMotionTs = 0L
    private var lastOcrAt = 0L
    private var lastStatusAt = 0L
    private var translateBackoffUntil = 0L

    private data class PendingLine(
        val id: Long,
        val key: String,
        val text: String,
        val source: String,
        val screenRect: RectF,
        val anchorScrollX: Float,
        val anchorScrollY: Float,
        val colors: PatchColors,
        val lineHeight: Float,
        val lineCount: Int,
        val epoch: Int
    )

    fun start() {
        stopped = false
        capture.start(metrics)
        reportStatus("正在读取屏幕…", force = true)
        scope.launch { warmUp() }
    }

    fun restartCapture(newMetrics: ScreenMetrics) {
        if (stopped) return
        epoch++
        metrics = newMetrics
        estimator.reset()
        scrollX = 0f
        scrollY = 0f
        lastMotionTs = 0L
        lastOcrAt = 0L
        pool.clear()
        overlay.updateMetrics(newMetrics)
        overlay.onScroll(0f, 0f, 0f, 0f, System.nanoTime(), 0f)
        capture.reconfigure(newMetrics)
        reportStatus("屏幕方向变化，重新同步…", force = true)
    }

    fun togglePause(): Boolean {
        paused = !paused
        overlay.setPaused(paused)
        if (!paused) {
            epoch++
            estimator.reset()
            scrollX = 0f
            scrollY = 0f
            lastMotionTs = 0L
            lastOcrAt = 0L
            overlay.onScroll(0f, 0f, 0f, 0f, System.nanoTime(), 0f)
            reportStatus("继续翻译", force = true)
        } else {
            reportStatus("已暂停", force = true)
        }
        return paused
    }

    fun isPaused(): Boolean = paused

    fun translatedBlocks(): Int = translatedCount.get()

    fun stop() {
        if (stopped) return
        stopped = true
        capture.stop()
        scope.cancel()
        // ML Kit clients must not be closed while a task may still be running.
        // Give in-flight recognize/translate calls a short grace period, then
        // close them off the main thread.
        val cleanupScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        cleanupScope.launch {
            delay(500)
            runCatching { ocr.close() }
            runCatching { translator.close() }
        }
        runCatching { memory.close() }
        pool.clear()
        overlay.clearBlocks()
        runCatching { dispatcher.close() }
    }

    private fun buildTranslator(): Translator = when (prefs.provider) {
        TranslationProvider.CLOUD -> CloudTranslator(
            baseUrl = prefs.apiBase,
            apiKey = prefs.apiKey,
            model = prefs.model
        )

        TranslationProvider.ON_DEVICE -> MlKitTranslator()
    }

    private fun warmUp() {
        if (stopped) return
        val sources = linkedSetOf(profile.baseLanguage)
        if (profile == SourceProfile.CHINESE || profile == SourceProfile.JAPANESE) {
            sources.add("en")
        }
        if (sources.size == 1 && sources.first() == target.id) {
            reportStatus("已就绪，滑动屏幕开始翻译", force = true)
            return
        }
        reportStatus("正在准备翻译模型（仅首次）…", force = true)
        try {
            translator.warmUp(sources, target.id)
            if (!stopped) reportStatus("已就绪，滑动屏幕开始翻译", force = true)
        } catch (t: Throwable) {
            if (!stopped) {
                reportStatus("模型准备失败：${shortError(t)}；可切换到云端 API", force = true)
            }
        }
    }

    private fun onFrame(frame: Bitmap, timestampNanos: Long) {
        if (stopped || paused) return
        val currentMetrics = metrics
        val expected = expectedCaptureSize(currentMetrics)
        if (frame.width != expected.first || frame.height != expected.second) {
            // A frame from before the latest rotation/resize; its pixels do not
            // match the current coordinate space. Drop it.
            return
        }
        val occlusions = overlay.renderOcclusionRects()
        val motion = try {
            estimator.estimate(
                frame = frame,
                timestampNanos = timestampNanos,
                screenWidth = currentMetrics.width,
                screenHeight = currentMetrics.height,
                occlusions = occlusions
            )
        } catch (_: Throwable) {
            ScrollEstimator.Motion(0f, 0f, 0f)
        }

        if (motion.isMoving) {
            val dt = if (lastMotionTs > 0L) {
                (timestampNanos - lastMotionTs) / 1_000_000_000f
            } else {
                0f
            }
            val instantVx = if (dt in 0.004f..0.20f) -motion.dx / dt else 0f
            val instantVy = if (dt in 0.004f..0.20f) -motion.dy / dt else 0f
            scrollX -= motion.dx
            scrollY -= motion.dy
            lastMotionTs = timestampNanos
            overlay.onScroll(
                scrollX = scrollX,
                scrollY = scrollY,
                instantVelocityX = instantVx,
                instantVelocityY = instantVy,
                timestampNanos = timestampNanos,
                confidence = motion.confidence
            )
        } else {
            overlay.onScroll(
                scrollX = scrollX,
                scrollY = scrollY,
                instantVelocityX = 0f,
                instantVelocityY = 0f,
                timestampNanos = timestampNanos,
                confidence = 0f
            )
        }

        maybeOcr(frame, currentMetrics.width, currentMetrics.height)
    }

    private fun expectedCaptureSize(m: ScreenMetrics): Pair<Int, Int> {
        val longSide = maxOf(m.width, m.height)
        if (longSide <= 0) return Pair(0, 0)
        val scale = minOf(
            Tuning.CAPTURE_SCALE,
            Tuning.CAPTURE_MAX_LONG_SIDE.toFloat() / longSide
        )
        val width = ((m.width * scale).toInt() / 2 * 2).coerceAtLeast(2)
        val height = ((m.height * scale).toInt() / 2 * 2).coerceAtLeast(2)
        return Pair(width, height)
    }

    private fun onCaptureError(t: Throwable) {
        if (!stopped) reportStatus("屏幕采集失败：${shortError(t)}", force = true)
    }

    private fun maybeOcr(frame: Bitmap, screenWidth: Int, screenHeight: Int) {
        val now = SystemClock.uptimeMillis()
        if (now - lastOcrAt < Tuning.OCR_INTERVAL_MS) return
        if (!ocrBusy.compareAndSet(false, true)) return
        lastOcrAt = now

        val snapshot = pool.acquire(frame.width, frame.height)
        Canvas(snapshot).drawBitmap(frame, 0f, 0f, null)
        val anchorX = scrollX
        val anchorY = scrollY
        val currentEpoch = epoch

        scope.launch {
            try {
                val text = ocr.recognize(snapshot)
                if (!stopped && currentEpoch == epoch) {
                    handleOcr(
                        text = text,
                        snapshot = snapshot,
                        anchorX = anchorX,
                        anchorY = anchorY,
                        frameWidth = frame.width,
                        frameHeight = frame.height,
                        screenWidth = screenWidth,
                        screenHeight = screenHeight,
                        epochAtCapture = currentEpoch
                    )
                }
            } catch (t: Throwable) {
                if (!stopped) reportStatus("识别失败：${shortError(t)}", force = false)
            } finally {
                pool.release(snapshot)
                ocrBusy.set(false)
            }
        }
    }

    private fun handleOcr(
        text: com.google.mlkit.vision.text.Text,
        snapshot: Bitmap,
        anchorX: Float,
        anchorY: Float,
        frameWidth: Int,
        frameHeight: Int,
        screenWidth: Int,
        screenHeight: Int,
        epochAtCapture: Int
    ) {
        val groups = OcrParser.parse(text)
        if (groups.isEmpty()) return
        val scaleX = screenWidth.toFloat() / frameWidth
        val scaleY = screenHeight.toFloat() / frameHeight
        val occlusions = overlay.occlusionRectsAt(anchorX, anchorY)
        val pending = ArrayList<PendingLine>()
        var cacheHits = 0

        for (group in groups) {
            if (epochAtCapture != epoch) return
            val screenRect = RectF(
                group.rect.left * scaleX,
                group.rect.top * scaleY,
                group.rect.right * scaleX,
                group.rect.bottom * scaleY
            )
            if (screenRect.width() < 8f || screenRect.height() < 6f) continue
            if (isOccluded(screenRect, occlusions)) continue
            if (memory.isOwnOutput(group.text)) continue

            val source = profile.sourceLanguageFor(group.text)
            val key = TextTools.cacheKey(source, target.id, group.text)
            val colors = ColorSampler.sample(snapshot, group.rect)
            val lineHeight = (group.lineHeight * scaleY).coerceAtLeast(6f)
            val cached = memory.get(key)
            if (cached != null) {
                if (overlay.renderAndAdd(
                        key = key,
                        sourceText = group.text,
                        translated = cached,
                        sourceRect = screenRect,
                        anchorScrollX = anchorX,
                        anchorScrollY = anchorY,
                        background = colors.background,
                        textColor = colors.text,
                        sourceLineHeight = lineHeight,
                        sourceLineCount = group.lineCount
                    )
                ) {
                    translatedCount.incrementAndGet()
                    cacheHits++
                }
            } else if (pendingKeys.add(key)) {
                pending.add(
                    PendingLine(
                        id = nextId.incrementAndGet(),
                        key = key,
                        text = group.text,
                        source = source,
                        screenRect = screenRect,
                        anchorScrollX = anchorX,
                        anchorScrollY = anchorY,
                        colors = colors,
                        lineHeight = lineHeight,
                        lineCount = group.lineCount,
                        epoch = epochAtCapture
                    )
                )
            }
        }

        if (pending.isNotEmpty() && !stopped) {
            scope.launch { translate(pending) }
        }
        if (cacheHits > 0) {
            reportStatus("已翻译 ${translatedCount.get()} 段", force = false)
        }
    }

    private suspend fun translate(lines: List<PendingLine>) {
        if (lines.isEmpty()) return
        // Lines measured before a pause/resume or rotation reset carry anchors in
        // the old coordinate space; rendering them now would draw misplaced patches.
        val active = lines.filter { it.epoch == epoch }
        if (active.isEmpty() || SystemClock.uptimeMillis() < translateBackoffUntil) {
            for (line in lines) pendingKeys.remove(line.key)
            return
        }
        try {
            val items = active.map { TranslationItem(it.id, it.text, it.source) }
            val results = translator.translate(items, target.id)
            if (stopped) return
            var added = 0
            for (line in active) {
                val translated = results[line.id]?.trim().orEmpty()
                if (translated.isEmpty()) continue
                memory.put(line.key, translated)
                val success = overlay.renderAndAdd(
                    key = line.key,
                    sourceText = line.text,
                    translated = translated,
                    sourceRect = line.screenRect,
                    anchorScrollX = line.anchorScrollX,
                    anchorScrollY = line.anchorScrollY,
                    background = line.colors.background,
                    textColor = line.colors.text,
                    sourceLineHeight = line.lineHeight,
                    sourceLineCount = line.lineCount
                )
                if (success) added++
            }
            if (added > 0) {
                translatedCount.addAndGet(added)
                reportStatus("已翻译 ${translatedCount.get()} 段", force = false)
            }
        } catch (t: Throwable) {
            translateBackoffUntil = SystemClock.uptimeMillis() + 3_500L
            reportStatus("翻译失败：${shortError(t)}", force = false)
        } finally {
            for (line in lines) pendingKeys.remove(line.key)
        }
    }

    private fun isOccluded(rect: RectF, occlusions: List<RectF>): Boolean {
        for (patch in occlusions) {
            if (overlapRatio(rect, patch) > 0.35f) return true
        }
        return false
    }

    private fun reportStatus(text: String, force: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (!force && now - lastStatusAt < 350L) return
        lastStatusAt = now
        onStatus(text, translatedCount.get())
    }

    private fun shortError(t: Throwable): String {
        val message = t.message?.trim().orEmpty()
        return message.take(60).ifEmpty { t.javaClass.simpleName }
    }
}
