package com.liuyi.flowtranslate.render

import android.graphics.RectF
import com.liuyi.flowtranslate.Tuning
import com.liuyi.flowtranslate.util.overlapRatio

/** Thread-safe immutable-snapshot store of rendered patches. */
class BlockStore {
    private val lock = Any()

    @Volatile
    private var blocks: List<RenderBlock> = emptyList()

    fun snapshot(): List<RenderBlock> = blocks

    fun count(): Int = blocks.size

    /**
     * True if a block with the same key already covers [rect] at the given anchor,
     * in which case rendering a new patch bitmap would be pure garbage.
     */
    fun hasNear(key: String, rect: RectF, anchorScrollX: Float, anchorScrollY: Float): Boolean {
        val snapshot = blocks
        for (existing in snapshot) {
            if (existing.key != key) continue
            val atNewAnchor = existing.screenRect(anchorScrollX, anchorScrollY)
            if (overlapRatio(atNewAnchor, rect) > 0.20f) return true
        }
        return false
    }

    fun add(block: RenderBlock): Boolean {
        synchronized(lock) {
            for (existing in blocks) {
                if (existing.key != block.key) continue
                val atNewAnchor = existing.screenRect(block.anchorScrollX, block.anchorScrollY)
                if (overlapRatio(atNewAnchor, block.baseRect) > 0.20f) return false
            }
            val next = ArrayList<RenderBlock>(blocks.size + 1)
            next.addAll(blocks)
            next.add(block)
            blocks = if (next.size > Tuning.MAX_BLOCKS) {
                next.subList(next.size - Tuning.MAX_BLOCKS, next.size).toList()
            } else {
                next
            }
            return true
        }
    }

    fun prune(scrollX: Float, scrollY: Float, screenWidth: Int, screenHeight: Int): Boolean {
        synchronized(lock) {
            if (blocks.isEmpty()) return false
            val kept = ArrayList<RenderBlock>(blocks.size)
            for (block in blocks) {
                val rect = block.screenRect(scrollX, scrollY)
                if (rect.bottom >= -screenHeight * 0.75f &&
                    rect.top <= screenHeight * 1.75f &&
                    rect.right >= -screenWidth * 0.5f &&
                    rect.left <= screenWidth * 1.5f
                ) {
                    kept.add(block)
                }
            }
            if (kept.size == blocks.size) return false
            blocks = kept
            return true
        }
    }

    fun occlusionRectsAt(
        scrollX: Float,
        scrollY: Float,
        screenWidth: Int,
        screenHeight: Int
    ): List<RectF> {
        val snapshot = blocks
        if (snapshot.isEmpty()) return emptyList()
        val result = ArrayList<RectF>(snapshot.size)
        for (block in snapshot) {
            val rect = block.screenRect(scrollX, scrollY)
            if (rect.right > 0f && rect.left < screenWidth &&
                rect.bottom > 0f && rect.top < screenHeight
            ) {
                result.add(rect)
            }
        }
        return result
    }

    fun clear() {
        synchronized(lock) { blocks = emptyList() }
    }
}
