package com.liuyi.flowtranslate.render

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF

data class PatchColors(val background: Int, val text: Int)

/**
 * Samples a ring just outside the OCR box and uses the median channel value.
 * A solid, locally-colored patch is what makes the translated layer look native
 * instead of like a black sticker — and an opaque patch is also what kills ghosting.
 */
object ColorSampler {
    fun sample(bitmap: Bitmap, rect: RectF): PatchColors {
        val left = rect.left.toInt().coerceIn(0, bitmap.width - 1)
        val top = rect.top.toInt().coerceIn(0, bitmap.height - 1)
        val right = rect.right.toInt().coerceIn(0, bitmap.width - 1)
        val bottom = rect.bottom.toInt().coerceIn(0, bitmap.height - 1)
        if (right <= left || bottom <= top) {
            return PatchColors(Color.rgb(20, 20, 20), Color.WHITE)
        }

        val pad = ((minOf(right - left, bottom - top) * 0.18f).toInt() + 2).coerceAtMost(10)
        val colors = IntArray(48)
        var count = 0

        fun add(x: Int, y: Int) {
            if (count >= colors.size) return
            val cx = x.coerceIn(0, bitmap.width - 1)
            val cy = y.coerceIn(0, bitmap.height - 1)
            colors[count++] = bitmap.getPixel(cx, cy)
        }

        val xs = intArrayOf(left, (left + right) / 2, right)
        val ys = intArrayOf(top, (top + bottom) / 2, bottom)
        for (x in xs) {
            add(x, top - pad)
            add(x, bottom + pad)
        }
        for (y in ys) {
            add(left - pad, y)
            add(right + pad, y)
        }
        if (count == 0) return PatchColors(Color.rgb(20, 20, 20), Color.WHITE)

        val rs = IntArray(count) { (colors[it] shr 16) and 0xFF }.sorted()
        val gs = IntArray(count) { (colors[it] shr 8) and 0xFF }.sorted()
        val bs = IntArray(count) { colors[it] and 0xFF }.sorted()
        val mid = count / 2
        val bg = Color.rgb(rs[mid], gs[mid], bs[mid])
        return PatchColors(bg, textColorFor(bg))
    }

    fun textColorFor(background: Int): Int {
        val r = Color.red(background)
        val g = Color.green(background)
        val b = Color.blue(background)
        val luminance = (0.2126f * r + 0.7152f * g + 0.0722f * b) / 255f
        return if (luminance > 0.56f) Color.rgb(17, 17, 17) else Color.rgb(250, 250, 250)
    }
}
