package com.liuyi.flowtranslate.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils as AndroidTextUtils
import kotlin.math.max
import kotlin.math.min

/**
 * Pre-renders a translated block into a single opaque bitmap.
 *
 * This is the core of the "no jank / no ghosting" guarantee:
 * - no text measurement, wrapping, or network work in onDraw / on the UI thread;
 * - one drawBitmap per block per frame;
 * - the patch is fully opaque, so the source text cannot bleed through;
 * - the view has no hardware layer, so no stale layer content can trail behind.
 */
class PatchRenderer(
    private val density: Float,
    private val densityDpi: Int
) {
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val typeface: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)

    data class Rendered(
        val patch: Bitmap,
        val coverRect: RectF
    )

    @Synchronized
    fun render(
        text: String,
        sourceRect: RectF,
        background: Int,
        textColor: Int,
        sourceLineHeight: Float,
        sourceLineCount: Int,
        screenWidth: Int,
        screenHeight: Int
    ): Rendered {
        val margin = 4f * density
        val padX = 3f * density
        val padY = 2f * density
        val minTextSize = 9f * density
        val maxWidth = (screenWidth - margin * 2f).coerceAtLeast(48f)

        var textSize = (sourceLineHeight * 0.62f).coerceIn(11f * density, 20f * density)
        var coverWidth = (sourceRect.width() + 6f * density).coerceIn(48f, maxWidth)
        val maxLines = if (sourceLineCount <= 1) 2 else 6

        var layout: StaticLayout? = null
        var coverHeight = 0f
        val hardMaxHeight = (screenHeight - margin * 2f).coerceAtLeast(32f)

        while (true) {
            textPaint.typeface = typeface
            textPaint.textSize = textSize
            textPaint.color = textColor
            val innerWidth = (coverWidth - padX * 2f).coerceAtLeast(24f)
            val candidate = StaticLayout.Builder
                .obtain(text, 0, text.length, textPaint, innerWidth.toInt())
                .setAlignment(
                    if (sourceLineCount <= 1) Layout.Alignment.ALIGN_CENTER
                    else Layout.Alignment.ALIGN_NORMAL
                )
                .setIncludePad(false)
                .setLineSpacing(0f, 1.02f)
                .setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE)
                .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
                .setMaxLines(maxLines)
                .setEllipsize(AndroidTextUtils.TruncateAt.END)
                .build()

            val desiredHeight = candidate.height + padY * 2f
            val allowedHeight = min(
                hardMaxHeight,
                max(
                    sourceRect.height() + padY * 4f,
                    sourceLineHeight * maxLines * 1.25f + padY * 2f
                )
            )
            if (desiredHeight <= allowedHeight || textSize <= minTextSize) {
                layout = candidate
                coverHeight = min(
                    max(desiredHeight, sourceRect.height() + padY * 2f),
                    hardMaxHeight
                )
                break
            }
            textSize = max(minTextSize, textSize - density)
        }

        val activeLayout = layout ?: StaticLayout.Builder
            .obtain(text, 0, text.length, textPaint, (coverWidth - padX * 2f).toInt().coerceAtLeast(24))
            .build()

        val width = coverWidth.toInt().coerceAtLeast(1)
        val height = coverHeight.toInt().coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bitmap.density = densityDpi
        val canvas = Canvas(bitmap)
        backgroundPaint.color = background
        val radius = 4f * density
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), radius, radius, backgroundPaint)

        val textX = ((width - activeLayout.width) / 2f).coerceAtLeast(0f)
        val textY = ((height - activeLayout.height) / 2f).coerceAtLeast(0f)
        canvas.save()
        canvas.translate(textX, textY)
        activeLayout.draw(canvas)
        canvas.restore()

        val centerX = sourceRect.centerX()
        val centerY = sourceRect.centerY()
        val left = (centerX - width / 2f).coerceIn(
            margin,
            max(margin, screenWidth - margin - width)
        )
        val top = (centerY - height / 2f).coerceIn(
            margin,
            max(margin, screenHeight - margin - height)
        )
        return Rendered(bitmap, RectF(left, top, left + width, top + height))
    }
}
