package com.liuyi.flowtranslate.render

import android.graphics.Bitmap
import android.graphics.RectF

/**
 * A translated patch anchored to content, not to the screen.
 *
 * [baseRect] was measured in screen coordinates when the screen was at
 * ([anchorScrollX], [anchorScrollY]). At a new scroll position the patch follows:
 *   x = baseRect.left + anchorScrollX - currentScrollX
 *   y = baseRect.top  + anchorScrollY - currentScrollY
 */
class RenderBlock(
    val key: String,
    val sourceText: String,
    val baseRect: RectF,
    val anchorScrollX: Float,
    val anchorScrollY: Float,
    val patch: Bitmap
) {
    fun leftAt(scrollX: Float): Float = baseRect.left + anchorScrollX - scrollX

    fun topAt(scrollY: Float): Float = baseRect.top + anchorScrollY - scrollY

    fun screenRect(scrollX: Float, scrollY: Float): RectF {
        val left = leftAt(scrollX)
        val top = topAt(scrollY)
        return RectF(left, top, left + patch.width, top + patch.height)
    }
}
