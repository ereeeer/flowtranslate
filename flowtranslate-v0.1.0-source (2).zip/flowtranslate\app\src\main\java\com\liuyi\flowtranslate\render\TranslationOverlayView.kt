package com.liuyi.flowtranslate.render

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.abs

/**
 * Full-screen, non-touchable layer. It only blits pre-rendered opaque patches.
 *
 * Deliberately no LAYER_TYPE_HARDWARE: a hardware layer can retain stale pixels on
 * some OEM compositors when content moves every frame, which is exactly the "拖影"
 * we are avoiding. A full redraw of ~20-40 bitmaps is cheap on the GPU.
 */
class TranslationOverlayView(context: Context) : View(context) {
    private var blocks: List<RenderBlock> = emptyList()
    private var scrollX = 0f
    private var scrollY = 0f
    private val bitmapPaint = Paint(Paint.DITHER_FLAG)

    init {
        setWillNotDraw(false)
        isFocusable = false
        isClickable = false
        setLayerType(LAYER_TYPE_NONE, null)
    }

    fun setBlocks(value: List<RenderBlock>) {
        if (value === blocks) return
        blocks = value
        invalidate()
    }

    fun setScroll(x: Float, y: Float) {
        if (abs(x - scrollX) < 0.01f && abs(y - scrollY) < 0.01f) return
        scrollX = x
        scrollY = y
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (block in blocks) {
            val x = block.leftAt(scrollX)
            val y = block.topAt(scrollY)
            if (x + block.patch.width < 0f || x > width.toFloat()) continue
            if (y + block.patch.height < 0f || y > height.toFloat()) continue
            canvas.drawBitmap(block.patch, x, y, bitmapPaint)
        }
    }
}
