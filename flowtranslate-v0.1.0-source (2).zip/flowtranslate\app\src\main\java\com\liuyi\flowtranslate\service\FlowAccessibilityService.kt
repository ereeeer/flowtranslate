package com.liuyi.flowtranslate.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.liuyi.flowtranslate.overlay.OverlayHost

/**
 * The overlay host.
 *
 * We do not read node content here. The service exists so the translation layer can
 * be a TYPE_ACCESSIBILITY_OVERLAY window: on Android 12+ those are trusted for touch
 * pass-through, unlike a full-screen TYPE_APPLICATION_OVERLAY obscuring the app.
 */
class FlowAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        OverlayHost.attach(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Deliberately empty: no node content is read.
    }

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        if (instance === this) instance = null
        OverlayHost.detach()
    }

    companion object {
        @Volatile
        var instance: FlowAccessibilityService? = null
            private set

        val isRunning: Boolean get() = instance != null
    }
}
