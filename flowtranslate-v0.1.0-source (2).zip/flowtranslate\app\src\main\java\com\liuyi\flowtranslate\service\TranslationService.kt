package com.liuyi.flowtranslate.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.liuyi.flowtranslate.MainActivity
import com.liuyi.flowtranslate.R
import com.liuyi.flowtranslate.data.Prefs
import com.liuyi.flowtranslate.data.RuntimeState
import com.liuyi.flowtranslate.model.ScreenMetrics
import com.liuyi.flowtranslate.overlay.OverlayController
import com.liuyi.flowtranslate.overlay.OverlayHost
import com.liuyi.flowtranslate.pipeline.TranslationPipeline

class TranslationService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: Prefs
    private var projection: MediaProjection? = null
    private var pipeline: TranslationPipeline? = null
    private var overlay: OverlayController? = null
    private var currentMetrics: ScreenMetrics? = null
    private var paused = false
    private var stopping = false

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY
        when (intent.action) {
            ACTION_START -> {
                if (projection != null) return START_NOT_STICKY
                startForegroundNow()
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = projectionData(intent)
                if (data == null) {
                    failAndStop("录屏授权数据无效")
                    return START_NOT_STICKY
                }
                startSession(resultCode, data)
            }

            ACTION_TOGGLE -> togglePause()

            ACTION_STOP -> stopSessionAndSelf()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handler.post {
            val newMetrics = ScreenMetrics.from(this)
            val current = currentMetrics
            val unchanged = current != null &&
                newMetrics.width == current.width &&
                newMetrics.height == current.height &&
                newMetrics.densityDpi == current.densityDpi
            if (unchanged) return@post
            currentMetrics = newMetrics
            pipeline?.restartCapture(newMetrics)
        }
    }

    override fun onDestroy() {
        if (!stopping) stopSessionAndSelf()
        super.onDestroy()
    }

    private fun startSession(resultCode: Int, data: Intent) {
        if (!OverlayHost.isReady()) {
            failAndStop(getString(R.string.accessibility_required))
            return
        }
        val manager = getSystemService(MediaProjectionManager::class.java)
        val mediaProjection = try {
            manager.getMediaProjection(resultCode, data)
        } catch (t: Throwable) {
            failAndStop("无法开始录屏：${t.message.orEmpty().take(50)}")
            return
        }
        if (mediaProjection == null) {
            failAndStop("录屏授权已失效，请重新开始")
            return
        }

        projection = mediaProjection
        mediaProjection.registerCallback(
            object : MediaProjection.Callback() {
                override fun onStop() {
                    handler.post {
                        if (!stopping) {
                            RuntimeState.status.value = "录屏已被系统停止"
                            stopSessionAndSelf()
                        }
                    }
                }

                override fun onCapturedContentResize(width: Int, height: Int) {
                    handler.post {
                        val current = currentMetrics ?: return@post
                        if (width == current.width && height == current.height) return@post
                        val updated = current.copy(width = width, height = height)
                        currentMetrics = updated
                        pipeline?.restartCapture(updated)
                    }
                }

                // Added in API 34; only invoked there. Pause instead of burning
                // battery while the captured content is not visible.
                override fun onCapturedContentVisibilityChanged(isVisible: Boolean) {
                    handler.post {
                        val currentPipeline = pipeline ?: return@post
                        if (!isVisible && !currentPipeline.isPaused()) {
                            currentPipeline.togglePause()
                            RuntimeState.status.value = "屏幕内容不可见，已自动暂停"
                        }
                    }
                }
            },
            handler
        )

        val screen = ScreenMetrics.from(this)
        currentMetrics = screen
        val shown = OverlayHost.show(
            metrics = screen,
            showBubble = prefs.bubbleEnabled,
            onToggle = { togglePause() },
            onLost = { onOverlayLost() }
        )
        if (!shown) {
            runCatching { mediaProjection.stop() }
            projection = null
            failAndStop(getString(R.string.accessibility_required))
            return
        }
        overlay = OverlayHost.controller()
        paused = false
        RuntimeState.begin()
        updateNotification()

        val newPipeline = try {
            TranslationPipeline(
                context = this,
                projection = mediaProjection,
                initialMetrics = screen,
                overlay = overlay!!,
                prefs = prefs,
                onStatus = { status, count -> handler.post { onPipelineStatus(status, count) } }
            )
        } catch (t: Throwable) {
            runCatching { mediaProjection.stop() }
            projection = null
            OverlayHost.hide()
            overlay = null
            RuntimeState.end()
            failAndStop("启动失败：${t.message.orEmpty().take(60)}")
            return
        }
        pipeline = newPipeline
        newPipeline.start()
    }

    private fun failAndStop(status: String) {
        RuntimeState.status.value = status
        stopping = true
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun togglePause() {
        val current = pipeline ?: return
        paused = current.togglePause()
        RuntimeState.paused.value = paused
        RuntimeState.status.value = if (paused) getString(R.string.status_paused) else "继续翻译"
        updateNotification()
    }

    private fun onPipelineStatus(status: String, count: Int) {
        RuntimeState.status.value = status
        RuntimeState.translatedCount.value = count
    }

    private fun onOverlayLost() {
        handler.post {
            if (stopping) return@post
            RuntimeState.status.value = "无障碍服务已关闭，翻译已停止"
            stopSessionAndSelf()
        }
    }

    private fun stopSessionAndSelf() {
        if (stopping) return
        stopping = true
        pipeline?.stop()
        pipeline = null
        OverlayHost.hide()
        overlay = null
        runCatching { projection?.stop() }
        projection = null
        paused = false
        RuntimeState.end()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startForegroundNow() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), type)
    }

    private fun updateNotification() {
        if (stopping) return
        runCatching {
            NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, buildNotification())
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val toggleIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, TranslationService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, TranslationService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = if (paused) {
            "已暂停 · 点“继续”恢复翻译"
        } else {
            getString(R.string.notification_text)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openIntent)
            .addAction(
                0,
                getString(if (paused) R.string.notification_resume else R.string.notification_pause),
                toggleIntent
            )
            .addAction(0, getString(R.string.notification_stop), stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notification_channel_description)
            setShowBadge(false)
            lockscreenVisibility = Notification.VISIBILITY_PRIVATE
        }
        manager.createNotificationChannel(channel)
    }

    private fun projectionData(intent: Intent): Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
    }

    companion object {
        private const val CHANNEL_ID = "flow_translation"
        private const val NOTIFICATION_ID = 8107
        private const val EXTRA_RESULT_CODE = "extra_result_code"
        private const val EXTRA_DATA = "extra_projection_data"
        const val ACTION_START = "com.liuyi.flowtranslate.action.START"
        const val ACTION_STOP = "com.liuyi.flowtranslate.action.STOP"
        const val ACTION_TOGGLE = "com.liuyi.flowtranslate.action.TOGGLE"

        fun start(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, TranslationService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA, data)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            runCatching {
                context.startService(
                    Intent(context, TranslationService::class.java).setAction(ACTION_STOP)
                )
            }
        }

        fun toggle(context: Context) {
            runCatching {
                context.startService(
                    Intent(context, TranslationService::class.java).setAction(ACTION_TOGGLE)
                )
            }
        }
    }
}
