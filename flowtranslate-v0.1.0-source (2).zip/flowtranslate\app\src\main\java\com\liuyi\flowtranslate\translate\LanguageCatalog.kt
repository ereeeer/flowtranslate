package com.liuyi.flowtranslate.translate

import com.liuyi.flowtranslate.util.TextTools

enum class RecognizerKind {
    LATIN,
    CHINESE,
    JAPANESE,
    KOREAN
}

/**
 * A recognition profile is not just a language: it selects the ML Kit script model.
 *
 * - CHINESE also recognizes Latin text, which covers mixed Chinese/English UIs.
 * - JAPANESE also recognizes Latin, which covers Japanese games with English names.
 * - For kanji-only Japanese lines we deliberately keep source=ja instead of guessing zh.
 */
enum class SourceProfile(
    val id: String,
    val label: String,
    val recognizer: RecognizerKind,
    val baseLanguage: String
) {
    CHINESE("zh", "中文 / 中英混排", RecognizerKind.CHINESE, "zh"),
    ENGLISH("en", "英语 / 拉丁语系", RecognizerKind.LATIN, "en"),
    JAPANESE("ja", "日语 / 日英混排", RecognizerKind.JAPANESE, "ja"),
    KOREAN("ko", "韩语", RecognizerKind.KOREAN, "ko");

    fun sourceLanguageFor(text: String): String = when (this) {
        CHINESE -> if (TextTools.containsHan(text)) "zh" else "en"
        ENGLISH -> "en"
        JAPANESE -> if (TextTools.containsKana(text) || TextTools.containsHan(text)) "ja" else "en"
        KOREAN -> if (TextTools.containsHangul(text)) "ko" else "en"
    }

    companion object {
        fun fromId(id: String?): SourceProfile =
            values().firstOrNull { it.id == id } ?: CHINESE
    }
}

enum class TargetLanguage(val id: String, val label: String) {
    CHINESE("zh", "简体中文"),
    ENGLISH("en", "English"),
    JAPANESE("ja", "日本語"),
    KOREAN("ko", "한국어");

    companion object {
        fun fromId(id: String?): TargetLanguage =
            values().firstOrNull { it.id == id } ?: CHINESE
    }
}
