package com.liuyi.flowtranslate.translate

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.translate.Translator as MlKitTranslatorApi
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Fully on-device translation. Language packs are downloaded once and then work offline.
 * ML Kit translators are not documented as thread-safe, so each language pair is guarded.
 */
class MlKitTranslator : Translator {
    private val lock = Any()
    private val translators = HashMap<String, MlKitTranslatorApi>()
    private val ready = HashSet<String>()
    private val mutexes = HashMap<String, Mutex>()

    private fun key(source: String, target: String) = "$source>$target"

    private fun mutexFor(key: String): Mutex = synchronized(lock) {
        mutexes.getOrPut(key) { Mutex() }
    }

    private suspend fun readyTranslator(source: String, target: String): MlKitTranslatorApi {
        val key = key(source, target)
        return mutexFor(key).withLock {
            val translator = synchronized(lock) {
                translators.getOrPut(key) {
                    Translation.getClient(
                        TranslatorOptions.Builder()
                            .setSourceLanguage(source)
                            .setTargetLanguage(target)
                            .build()
                    )
                }
            }
            val isReady = synchronized(lock) { ready.contains(key) }
            if (!isReady) {
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                synchronized(lock) { ready.add(key) }
            }
            translator
        }
    }

    override suspend fun translate(
        items: List<TranslationItem>,
        targetLanguage: String
    ): Map<Long, String> {
        val out = HashMap<Long, String>(items.size)
        for (item in items) {
            val source = item.sourceLanguage
            if (source == targetLanguage) {
                out[item.id] = item.text
                continue
            }
            val key = key(source, targetLanguage)
            try {
                val translator = readyTranslator(source, targetLanguage)
                out[item.id] = translator.translate(item.text).await()
            } catch (_: Exception) {
                // Model may have been evicted; retry once on the next pass.
                synchronized(lock) { ready.remove(key) }
            }
        }
        return out
    }

    override suspend fun warmUp(sourceLanguages: Set<String>, targetLanguage: String) {
        for (source in sourceLanguages) {
            if (source == targetLanguage) continue
            try {
                readyTranslator(source, targetLanguage)
            } catch (_: Exception) {
                // The pipeline surfaces a useful status on the first failed translation.
            }
        }
    }

    override fun close() {
        val copy = synchronized(lock) {
            val values = translators.values.toList()
            translators.clear()
            ready.clear()
            mutexes.clear()
            values
        }
        for (translator in copy) {
            runCatching { translator.close() }
        }
    }
}
