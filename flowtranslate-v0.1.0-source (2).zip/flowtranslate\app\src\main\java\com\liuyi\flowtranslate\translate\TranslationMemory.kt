package com.liuyi.flowtranslate.translate

import android.content.Context
import android.util.LruCache
import com.liuyi.flowtranslate.util.TextTools
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/**
 * LRU translation memory persisted to internal storage.
 *
 * Two jobs:
 * 1. Re-scrolling over already-seen text is instant (no OCR cost for the translation,
 *    only the recognition pass that finds the line again).
 * 2. Rendered target-language strings are remembered so a capture that includes our
 *    own overlay does not get translated again.
 */
class TranslationMemory(context: Context) {
    private val lock = Any()
    private val saveLock = Any()
    private val file = File(context.applicationContext.filesDir, FILE_NAME)
    private val cache = object : LruCache<String, String>(MAX_ENTRIES) {}
    private val ownOutputs = HashSet<String>()
    private val io = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "translation-memory").apply { isDaemon = true }
    }

    @Volatile
    private var saveScheduled = false

    @Volatile
    private var closed = false

    init {
        load()
    }

    fun get(key: String): String? = synchronized(lock) { cache.get(key) }

    fun put(key: String, translation: String) {
        val value = translation.trim()
        if (value.isEmpty()) return
        val normalized = TextTools.normalize(value)
        synchronized(lock) {
            cache.put(key, value)
            if (normalized.length >= 4) {
                ownOutputs.add(normalized)
                if (ownOutputs.size > MAX_OWN_OUTPUTS) {
                    ownOutputs.clear()
                    for (v in cache.snapshot().values) {
                        val n = TextTools.normalize(v)
                        if (n.length >= 4) ownOutputs.add(n)
                    }
                }
            }
        }
        scheduleSave()
    }

    /**
     * A conservative check for "this OCR line is our own Chinese/English patch".
     * Occlusion rectangles are the primary filter; this catches the rare pixel-perfect miss.
     */
    fun isOwnOutput(text: String): Boolean {
        val normalized = TextTools.normalize(text)
        if (normalized.length < 4) return false
        return synchronized(lock) { ownOutputs.contains(normalized) }
    }

    fun copyAll(): Map<String, String> = synchronized(lock) { HashMap(cache.snapshot()) }

    fun flush() {
        saveNow()
    }

    fun close() {
        if (closed) return
        closed = true
        saveNow()
        io.shutdownNow()
    }

    private fun load() {
        if (!file.exists()) return
        try {
            val root = JSONObject(file.readText(Charsets.UTF_8))
            val entries = root.optJSONObject("entries") ?: root
            val keys = entries.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = entries.optString(key, "")
                if (key.isNotEmpty() && value.isNotEmpty()) {
                    cache.put(key, value)
                }
            }
            for (value in cache.snapshot().values) {
                val normalized = TextTools.normalize(value)
                if (normalized.length >= 4) ownOutputs.add(normalized)
            }
        } catch (_: Exception) {
            // A corrupt cache is not worth crashing over.
        }
    }

    private fun scheduleSave() {
        if (closed) return
        synchronized(lock) {
            if (saveScheduled) return
            saveScheduled = true
        }
        io.execute {
            try {
                Thread.sleep(1_200)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
            saveNow()
            saveScheduled = false
        }
    }

    private fun saveNow() {
        // Serialize writes: close() saves from the main thread while the memory
        // I/O thread may be saving from a debounced schedule.
        synchronized(saveLock) {
            val snapshot = synchronized(lock) { HashMap(cache.snapshot()) }
            if (snapshot.isEmpty()) return
            try {
                val entries = JSONObject()
                for ((key, value) in snapshot) entries.put(key, value)
                val root = JSONObject()
                    .put("version", 1)
                    .put("entries", entries)
                val tmp = File(file.parentFile, "$FILE_NAME.tmp")
                tmp.writeText(root.toString(), Charsets.UTF_8)
                if (file.exists()) file.delete()
                if (!tmp.renameTo(file)) {
                    file.writeText(root.toString(), Charsets.UTF_8)
                    tmp.delete()
                }
            } catch (_: Exception) {
                // Persistence is best effort; in-memory cache still works.
            }
        }
    }

    companion object {
        private const val FILE_NAME = "translation_memory.json"
        private const val MAX_ENTRIES = 1_500
        private const val MAX_OWN_OUTPUTS = 4_000
    }
}
