package com.liuyi.flowtranslate.translate

data class TranslationItem(
    val id: Long,
    val text: String,
    val sourceLanguage: String
)

interface Translator {
    suspend fun translate(items: List<TranslationItem>, targetLanguage: String): Map<Long, String>

    /** Downloads on-device models, or is a no-op for cloud engines. */
    suspend fun warmUp(sourceLanguages: Set<String>, targetLanguage: String)

    fun close()
}
