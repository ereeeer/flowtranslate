package com.liuyi.flowtranslate.util

import android.graphics.Bitmap
import java.util.ArrayDeque

/**
 * Fixed-size reusable bitmap pool for OCR snapshots. Reusing the ~3 MB snapshot
 * avoids GC churn on the capture thread, which is a major source of scroll stutter.
 * On a pool miss a new bitmap is allocated: the in-flight cap (one snapshot at a
 * time via [com.liuyi.flowtranslate.pipeline.TranslationPipeline]'s ocrBusy) plus
 * the free-list size keeps memory bounded.
 */
class BitmapPool(private val maxSize: Int) {
    private val free = ArrayDeque<Bitmap>()

    @Synchronized
    fun acquire(width: Int, height: Int): Bitmap {
        while (free.isNotEmpty()) {
            val bitmap = free.removeLast()
            if (!bitmap.isRecycled && bitmap.width == width && bitmap.height == height) {
                return bitmap
            }
            bitmap.recycle()
        }
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
            // Copied 1:1 from the capture bitmap; a density here would make
            // Canvas.drawBitmap rescale the snapshot.
            density = Bitmap.DENSITY_NONE
        }
    }

    @Synchronized
    fun release(bitmap: Bitmap) {
        if (bitmap.isRecycled) return
        if (free.size < maxSize) {
            free.addLast(bitmap)
        } else {
            bitmap.recycle()
        }
    }

    @Synchronized
    fun clear() {
        for (bitmap in free) bitmap.recycle()
        free.clear()
    }
}
