package com.liuyi.flowtranslate.util

import android.graphics.RectF

fun overlapArea(a: RectF, b: RectF): Float {
    val left = maxOf(a.left, b.left)
    val top = maxOf(a.top, b.top)
    val right = minOf(a.right, b.right)
    val bottom = minOf(a.bottom, b.bottom)
    if (right <= left || bottom <= top) return 0f
    return (right - left) * (bottom - top)
}

/** Intersection divided by the smaller rectangle. Useful for duplicate/occlusion tests. */
fun overlapRatio(a: RectF, b: RectF): Float {
    val inter = overlapArea(a, b)
    if (inter <= 0f) return 0f
    val smaller = minOf(a.width() * a.height(), b.width() * b.height())
    return if (smaller <= 0f) 0f else inter / smaller
}
