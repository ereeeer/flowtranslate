package com.liuyi.flowtranslate.util

import java.util.Locale

/** Text normalization used for cache keys and for rejecting our own rendered translations. */
object TextTools {
    private val removable = Regex("[\\s\\p{P}\\p{S}]")

    fun normalize(text: String): String =
        text.lowercase(Locale.ROOT).replace(removable, "")

    fun containsHan(text: String): Boolean =
        text.any { Character.UnicodeScript.of(it.code) == Character.UnicodeScript.HAN }

    fun containsKana(text: String): Boolean =
        text.any {
            val script = Character.UnicodeScript.of(it.code)
            script == Character.UnicodeScript.HIRAGANA || script == Character.UnicodeScript.KATAKANA
        }

    fun containsHangul(text: String): Boolean =
        text.any { Character.UnicodeScript.of(it.code) == Character.UnicodeScript.HANGUL }

    fun cacheKey(sourceLanguage: String, targetLanguage: String, text: String): String =
        "$sourceLanguage>$targetLanguage|${normalize(text)}"

    fun hasUsefulText(text: String): Boolean =
        text.any { it.isLetterOrDigit() } && text.count { !it.isWhitespace() } >= 1

    fun oneLine(text: String, maxChars: Int = 80): String =
        text.replace('\n', ' ').trim().take(maxChars)
}
