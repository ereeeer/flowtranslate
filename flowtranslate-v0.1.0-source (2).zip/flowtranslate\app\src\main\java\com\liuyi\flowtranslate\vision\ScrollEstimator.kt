package com.liuyi.flowtranslate.vision

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Estimates content movement between two captured frames with a coarse-to-fine
 * normalized SAD search. It is intentionally cheap: the captured frame is reduced
 * to a 360-px-long luminance image and pixels covered by our own overlay are masked
 * out. Masking is essential — otherwise the overlay would "track itself" and create
 * a feedback loop where predicted motion becomes measured motion.
 */
class ScrollEstimator {
    data class Motion(val dx: Float, val dy: Float, val confidence: Float) {
        val isMoving: Boolean get() = confidence > 0.12f && (abs(dx) > 0.25f || abs(dy) > 0.25f)
    }

    private data class AxisShift(val shift: Float, val confidence: Float, val raw: Int)

    private var analysis: Bitmap? = null
    private var canvas: Canvas? = null
    private var pixels = IntArray(0)
    private var current = ByteArray(0)
    private var previous = ByteArray(0)
    private var mask = BooleanArray(0)
    private var errors = FloatArray(0)
    private var width = 0
    private var height = 0
    private var hasPrevious = false
    private var lastTimestamp = 0L
    private val dst = Rect()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)

    fun reset() {
        analysis?.recycle()
        analysis = null
        canvas = null
        pixels = IntArray(0)
        current = ByteArray(0)
        previous = ByteArray(0)
        mask = BooleanArray(0)
        errors = FloatArray(0)
        width = 0
        height = 0
        hasPrevious = false
        lastTimestamp = 0L
    }

    fun estimate(
        frame: Bitmap,
        timestampNanos: Long,
        screenWidth: Int,
        screenHeight: Int,
        occlusions: List<RectF>
    ): Motion {
        ensure(frame.width, frame.height)
        val bitmap = analysis ?: return Motion(0f, 0f, 0f)
        dst.set(0, 0, width, height)
        canvas?.drawBitmap(frame, null, dst, paint) ?: return Motion(0f, 0f, 0f)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val count = width * height
        for (i in 0 until count) {
            val color = pixels[i]
            val r = (color shr 16) and 0xFF
            val g = (color shr 8) and 0xFF
            val b = color and 0xFF
            current[i] = ((r * 77 + g * 150 + b * 29) shr 8).toByte()
        }

        markOcclusions(occlusions, screenWidth, screenHeight)
        var masked = 0
        for (m in mask) if (m) masked++
        val cleanRatio = 1f - masked.toFloat() / count
        if (cleanRatio < 0.18f) {
            rotateBuffers()
            hasPrevious = true
            lastTimestamp = timestampNanos
            return Motion(0f, 0f, 0f)
        }

        if (!hasPrevious || timestampNanos - lastTimestamp > 600_000_000L) {
            rotateBuffers()
            hasPrevious = true
            lastTimestamp = timestampNanos
            return Motion(0f, 0f, 0f)
        }

        if (!hasTexture()) {
            rotateBuffers()
            lastTimestamp = timestampNanos
            return Motion(0f, 0f, 0f)
        }

        val vertical = findVertical()
        val horizontal = findHorizontal(vertical?.raw ?: 0)
        val verticalShift = vertical?.takeIf { it.confidence >= 0.12f }
        val horizontalShift = horizontal?.takeIf { it.confidence >= 0.16f }

        val confidence = max(verticalShift?.confidence ?: 0f, horizontalShift?.confidence ?: 0f)
        if (confidence < 0.12f) {
            rotateBuffers()
            lastTimestamp = timestampNanos
            return Motion(0f, 0f, 0f)
        }

        val dy = verticalShift?.shift ?: 0f
        val dx = horizontalShift?.shift ?: 0f
        rotateBuffers()
        lastTimestamp = timestampNanos

        // Convert analysis pixels to screen pixels. Analysis keeps the capture aspect,
        // so screenWidth / analysisWidth is the only scale needed.
        return Motion(
            dx = dx * screenWidth.toFloat() / width,
            dy = dy * screenHeight.toFloat() / height,
            confidence = confidence
        )
    }

    private fun ensure(frameWidth: Int, frameHeight: Int) {
        val longSide = max(frameWidth, frameHeight)
        if (longSide <= 0) return
        val scale = TARGET_LONG_SIDE.toFloat() / longSide
        val w = max(48, (frameWidth * scale).toInt())
        val h = max(48, (frameHeight * scale).toInt())
        if (w == width && h == height && analysis != null) return
        analysis?.recycle()
        width = w
        height = h
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bitmap.density = Bitmap.DENSITY_NONE
        analysis = bitmap
        canvas = Canvas(bitmap)
        pixels = IntArray(w * h)
        current = ByteArray(w * h)
        previous = ByteArray(w * h)
        mask = BooleanArray(w * h)
        errors = FloatArray(max(1, (h / 3) * 2 + 1))
        hasPrevious = false
    }

    private fun markOcclusions(occlusions: List<RectF>, screenWidth: Int, screenHeight: Int) {
        java.util.Arrays.fill(mask, false)
        if (occlusions.isEmpty() || screenWidth <= 0 || screenHeight <= 0) return
        val sx = width.toFloat() / screenWidth
        val sy = height.toFloat() / screenHeight
        for (rect in occlusions) {
            val left = (rect.left * sx).toInt() - 2
            val top = (rect.top * sy).toInt() - 2
            val right = (rect.right * sx).toInt() + 2
            val bottom = (rect.bottom * sy).toInt() + 2
            val l = left.coerceIn(0, width - 1)
            val t = top.coerceIn(0, height - 1)
            val r = right.coerceIn(l, width - 1)
            val b = bottom.coerceIn(t, height - 1)
            for (y in t..b) {
                val row = y * width
                for (x in l..r) mask[row + x] = true
            }
        }
    }

    private fun hasTexture(): Boolean {
        var sum = 0.0
        var sumSq = 0.0
        var n = 0
        val step = 4
        var y = 0
        while (y < height) {
            val row = y * width
            var x = 0
            while (x < width) {
                if (!mask[row + x]) {
                    val v = previous[row + x].toInt() and 0xFF
                    sum += v
                    sumSq += v.toDouble() * v
                    n++
                }
                x += step
            }
            y += step
        }
        if (n < 120) return false
        val mean = sum / n
        val variance = sumSq / n - mean * mean
        return variance > 18.0
    }

    private fun findVertical(): AxisShift? {
        val maxShift = max(4, height / 4)
        val total = maxShift * 2 + 1
        if (errors.size < total) errors = FloatArray(total)
        val xStep = max(1, width / 60)
        val yStep = max(1, height / 60)
        val minSamples = max(240, (width / xStep) * (height / yStep) / 12)

        var bestIndex = 0
        var bestError = Float.MAX_VALUE
        var zeroError = Float.MAX_VALUE

        for (dy in -maxShift..maxShift) {
            val startY = max(0, dy)
            val endY = min(height, height + dy)
            var sum = 0L
            var samples = 0
            var y = startY
            while (y < endY) {
                val currentRow = y * width
                val previousRow = (y - dy) * width
                var x = 0
                while (x < width) {
                    if (!mask[currentRow + x] && !mask[previousRow + x]) {
                        val a = current[currentRow + x].toInt() and 0xFF
                        val b = previous[previousRow + x].toInt() and 0xFF
                        sum += abs(a - b)
                        samples++
                    }
                    x += xStep
                }
                y += yStep
            }
            val index = dy + maxShift
            val error = if (samples < minSamples) {
                Float.MAX_VALUE
            } else {
                sum.toFloat() / samples + 0.012f * abs(dy) / maxShift
            }
            errors[index] = error
            if (error < bestError) {
                bestError = error
                bestIndex = index
            }
            if (dy == 0) zeroError = error
        }

        if (bestError == Float.MAX_VALUE || zeroError == Float.MAX_VALUE) return null
        if (bestError > 26f) return null
        // Relative improvement test instead of an absolute floor: slow scrolling
        // (a few screen px per frame) produces small absolute errors but a real,
        // repeatable SAD improvement; static noise does not.
        val improvement = zeroError - bestError
        if (improvement <= max(0.45f, 0.08f * zeroError)) return null
        val rawBest = bestIndex - maxShift
        val shift = rawBest + subpixel(errors, bestIndex)
        val confidence = (improvement / max(zeroError, 2.5f)).coerceIn(0f, 1f)
        if (confidence < 0.10f) return null
        return AxisShift(shift, confidence, rawBest)
    }

    private fun findHorizontal(verticalRaw: Int): AxisShift? {
        val maxShift = max(4, width / 4)
        val total = maxShift * 2 + 1
        if (errors.size < total) errors = FloatArray(total)
        val xStep = max(1, width / 60)
        val yStep = max(1, height / 60)
        val minSamples = max(200, (width / xStep) * (height / yStep) / 14)

        var bestIndex = 0
        var bestError = Float.MAX_VALUE
        var zeroError = Float.MAX_VALUE
        val startY = max(0, verticalRaw)
        val endY = min(height, height + verticalRaw)

        for (dx in -maxShift..maxShift) {
            val startX = max(0, dx)
            val endX = min(width, width + dx)
            var sum = 0L
            var samples = 0
            var y = startY
            while (y < endY) {
                val currentRow = y * width
                val previousRow = (y - verticalRaw) * width
                var x = startX
                while (x < endX) {
                    if (!mask[currentRow + x] && !mask[previousRow + (x - dx)]) {
                        val a = current[currentRow + x].toInt() and 0xFF
                        val b = previous[previousRow + (x - dx)].toInt() and 0xFF
                        sum += abs(a - b)
                        samples++
                    }
                    x += xStep
                }
                y += yStep
            }
            val index = dx + maxShift
            val error = if (samples < minSamples) {
                Float.MAX_VALUE
            } else {
                sum.toFloat() / samples + 0.012f * abs(dx) / maxShift
            }
            errors[index] = error
            if (error < bestError) {
                bestError = error
                bestIndex = index
            }
            if (dx == 0) zeroError = error
        }

        if (bestError == Float.MAX_VALUE || zeroError == Float.MAX_VALUE) return null
        if (bestError > 26f) return null
        val improvement = zeroError - bestError
        if (improvement <= max(0.45f, 0.08f * zeroError)) return null
        val rawBest = bestIndex - maxShift
        val shift = rawBest + subpixel(errors, bestIndex)
        val confidence = (improvement / max(zeroError, 2.5f)).coerceIn(0f, 1f)
        if (confidence < 0.14f) return null
        return AxisShift(shift, confidence, rawBest)
    }

    private fun subpixel(values: FloatArray, index: Int): Float {
        val center = values[index]
        if (center == Float.MAX_VALUE) return 0f
        val prev = if (index > 0) values[index - 1] else center
        val next = if (index < values.lastIndex) values[index + 1] else center
        if (prev == Float.MAX_VALUE || next == Float.MAX_VALUE) return 0f
        val denominator = prev - 2f * center + next
        if (abs(denominator) < 0.0001f) return 0f
        return (0.5f * (prev - next) / denominator).coerceIn(-0.5f, 0.5f)
    }

    private fun rotateBuffers() {
        val tmp = previous
        previous = current
        current = tmp
    }

    companion object {
        private const val TARGET_LONG_SIDE = 360
    }
}
