package com.liuyi.flowtranslate.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextToolsTest {

    @Test
    fun normalizeStripsPunctuationSpacesAndCase() {
        assertEquals("ok", TextTools.normalize("OK."))
        assertEquals("你好", TextTools.normalize("你 好！"))
        assertEquals("abc123", TextTools.normalize("A b c - 1 2 3"))
    }

    @Test
    fun detectsEastAsianScripts() {
        assertTrue(TextTools.containsHan("你好abc"))
        assertFalse(TextTools.containsHan("hello"))
        assertTrue(TextTools.containsKana("こんにちは"))
        assertTrue(TextTools.containsKana("カタカナ"))
        assertFalse(TextTools.containsKana("hello"))
        assertTrue(TextTools.containsHangul("안녕하세요"))
    }

    @Test
    fun cacheKeyIsStableAcrossFormatting() {
        val first = TextTools.cacheKey("en", "zh", "Hello, world!")
        val second = TextTools.cacheKey("en", "zh", "hello world")
        assertEquals(first, second)
    }

    @Test
    fun usefulTextFiltering() {
        assertTrue(TextTools.hasUsefulText("Start"))
        assertFalse(TextTools.hasUsefulText("---"))
    }
}
