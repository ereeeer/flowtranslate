﻿# 一键构建 APK（Windows）
# 双击本脚本，或在项目目录执行:  powershell -ExecutionPolicy Bypass -File .\build-apk.ps1
# 流程：找 JDK 17 -> 找 Android SDK -> 自动下载 Gradle 8.7（国内镜像优先）-> 编译 debug APK

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

Write-Host "======================================" -ForegroundColor Cyan
Write-Host "  流译 FlowTranslate - 一键构建 APK" -ForegroundColor Cyan
Write-Host "======================================" -ForegroundColor Cyan
Write-Host ""

# ---------- 1. 定位 Android SDK ----------
$sdkDir = $null
if (Test-Path (Join-Path $root "local.properties")) {
    $content = Get-Content (Join-Path $root "local.properties") -Raw
    $m = [regex]::Match($content, '(?m)^\s*sdk\.dir\s*=\s*(.+?)\s*$')
    if ($m.Success) {
        $sdkDir = $m.Groups[1].Value.Trim().Replace('\:', ':')
    }
}
if (-not $sdkDir -and $env:ANDROID_HOME) { $sdkDir = $env:ANDROID_HOME }
if (-not $sdkDir -and (Test-Path (Join-Path $env:LOCALAPPDATA "Android\Sdk\platforms\android-34"))) {
    $sdkDir = Join-Path $env:LOCALAPPDATA "Android\Sdk"
}

if ($sdkDir -and (Test-Path (Join-Path $sdkDir "platforms\android-34"))) {
    Write-Host "使用 Android SDK: $sdkDir" -ForegroundColor Green
    $env:ANDROID_HOME = $sdkDir
    if (-not (Test-Path (Join-Path $root "local.properties"))) {
        "sdk.dir=" + ($sdkDir -replace '\\', '/') | Set-Content (Join-Path $root "local.properties") -Encoding ascii
    }
} else {
    Write-Host "没有找到 Android SDK（需要 platforms;android-34）。" -ForegroundColor Red
    Write-Host ""
    Write-Host "二选一："
    Write-Host "  A. 安装 Android Studio（自带 SDK，推荐新手）："
    Write-Host "     官方: https://developer.android.google.cn/studio"
    Write-Host "     清华镜像: https://mirrors.tuna.tsinghua.edu.cn/AndroidStudio/"
    Write-Host "     装完打开项目让它同步一次，再回来运行本脚本。"
    Write-Host "  B. 不想装 Android Studio：先运行 .\setup-sdk.ps1 自动下载 SDK，再运行本脚本。"
    Write-Host ""
    Read-Host "按回车键退出"
    exit 1
}

# ---------- 2. 编译 ----------
& "$root\gradlew.bat" :app:assembleDebug
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "构建失败，请把上面日志发给开发者排查。" -ForegroundColor Red
    Write-Host "常见原因：依赖下载中断（重试一次即可）、JDK 版本低于 17。" -ForegroundColor Yellow
    Read-Host "按回车键退出"
    exit $LASTEXITCODE
}

# ---------- 3. 结果 ----------
$apk = Join-Path $root "app\build\outputs\apk\debug\app-debug.apk"
if (Test-Path $apk) {
    Write-Host ""
    Write-Host "构建成功！" -ForegroundColor Green
    Write-Host "APK 位置：$apk"
    Write-Host ""
    Write-Host "把 app-debug.apk 传到手机安装，然后："
    Write-Host "  1. 打开「流译」→ 开启无障碍服务"
    Write-Host "  2. 点「开始翻译」→ 允许录屏"
    Write-Host "  3. 回到小说/漫画/游戏/网页，正常滑动即可"
    Write-Host ""
    Start-Process explorer.exe "/select,$apk"
} else {
    Write-Host "构建完成但找不到 APK 文件，请检查上方日志。" -ForegroundColor Red
}

Read-Host "按回车键退出"
