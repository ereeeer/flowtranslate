# 流译架构：滚动翻译为什么不卡、不拖影

本文解释核心设计决策与数学，方便你修改和二次开发。先记住一句话：

> **滚动跟手与翻译生产是两条独立的时间线。滚动线永远不等翻译线。**

---

## 1. 总体数据流

```
                   ┌──────────────────────────────────────────────────────────────┐
                   │                        系统合成层                              │
  目标 App ────────┼──► MediaProjection 采集 ──► ImageReader (RGBA_8888, 720x1600)  │
                   │        │                                                       │
                   │        │ 每帧(24fps, 节流+丢帧)                                 │
                   │        ▼                                                       │
                   │  ScrollEstimator 帧差测速（自己渲染的译文块被掩码）               │
                   │        │                                                       │
                   │        │ (dx, dy, confidence)                                 │
                   │        ▼                                                       │
                   │  OverlayController.Choreographer (60/120Hz 速度外推)           │
                   │        │                                                       │
                   │        ▼                                                       │
                   │  TranslationOverlayView.onDraw —— 只 drawBitmap               │
                   │                                                               │
                   │  每 300ms 且 OCR 空闲时：拷贝一帧快照（BitmapPool 复用）          │
                   │        ▼                                                       │
                   │  ML Kit OCR ──► 行分组 ──► 排除已渲染区域/自己的译文             │
                   │        ▼                                                       │
                   │  翻译记忆命中？──是──► 直接渲染贴图                               │
                   │        │否                                                    │
                   │        ▼                                                       │
                   │  端侧 / 云端翻译 ──► TranslationMemory ──► PatchRenderer        │
                   │                              └────────► BlockStore ──► 发布    │
                   └──────────────────────────────────────────────────────────────┘
```

两条时间线：

| 时间线 | 频率 | 干什么 | 会阻塞吗 |
| --- | --- | --- | --- |
| 滚动线 | 采集 24fps，渲染 60/120Hz | 测位移、外推、移动译文块 | 不等待任何翻译 |
| 翻译线 | OCR ≤ 3.3 次/秒 | 识别、翻译、排版、生成贴图 | 不影响画面 |

---

## 2. 为什么用无障碍悬浮层（TYPE_ACCESSIBILITY_OVERLAY）

Android 12+ 的“不可信触摸”机制：全屏、高不透明度的 `TYPE_APPLICATION_OVERLAY` 会被系统视为遮挡，从而拦截下层 App 的触摸事件（即使设置了 `FLAG_NOT_TOUCHABLE`）。而 `TYPE_ACCESSIBILITY_OVERLAY` 是系统信任的无障碍层，可以全屏绘制且让触摸穿透。

代价：需要用户开启无障碍服务。为最小化隐私顾虑，本项目的无障碍服务配置为 `canRetrieveWindowContent="false"`，**不读取任何节点内容**，只负责创建悬浮层。

窗口参数要点（`OverlayController.buildParams()`）：

- `FLAG_NOT_FOCUSABLE | FLAG_NOT_TOUCHABLE | FLAG_NOT_TOUCH_MODAL`：全屏层不抢焦点、不拦截手势；
- `FLAG_LAYOUT_IN_SCREEN | FLAG_LAYOUT_NO_LIMITS` + API 30+ `fitInsetsTypes = 0`：让窗口坐标与 MediaProjection 的全屏坐标一致（包含状态栏区域）；
- 悬浮球是**单独一个**小窗口（touchable），除此之外没有任何可触摸窗口。

---

## 3. 坐标与锚定

所有“译文块”都锚定在**内容**上，而不是屏幕上：

```
内容向下滚动 s 像素时（屏幕上移 -s）：
  块在屏幕上的新位置 = baseRect + (anchorScroll - currentScroll)

  x = baseX + anchorScrollX - scrollX
  y = baseY + anchorScrollY - scrollY
```

OCR 结果产生时，记录当时的绝对滚动值 `(anchorScrollX, anchorScrollY)` 和框的屏幕坐标 `baseRect`。之后无论 OCR/翻译花了多久、屏幕怎么滚，贴图都能按上式放回正确的内容位置。

位移量纲统一为**屏幕像素**。采集帧是 `CAPTURE_SCALE` 缩小后的，转换关系：

```
screenDelta = analysisDelta × screenSize / analysisSize
```

---

## 4. 滚动估计（ScrollEstimator）

### 4.1 粗到细的归一化 SAD 搜索

1. 把采集帧缩小到长边 360 px 的灰度图（约 162×360），`getPixels` 一次取走，逐像素转亮度 `0.30R+0.59G+0.11B`。
2. 竖向搜索 `dy ∈ [-h/4, +h/4]`：当前帧第 `y` 行与上一帧第 `y-dy` 行比对，求平均绝对差；横向同理。
3. 取误差最小的整像素位移，再用三点抛物线求**亚像素**位移（±0.5 分析像素 ≈ ±2 屏幕像素）。
4. 置信度：`(零位移误差 - 最佳误差) / max(零位移误差, 6)`，并要求最佳误差足够小、画面有纹理。

### 4.2 反馈隔离（最关键的一步）

悬浮层本身会被 MediaProjection 采集进画面。如果不用掩码，译文块跟着“预测速度”移动，下一帧就会把**译文块自己的移动**当成内容滚动——预测误差被放大成真实误差，译文层会越漂越快。

解决：测速前把 `BlockStore` 里所有译文块（换算到当前滚动位置）在分析图上**掩码掉**，只统计干净区域的像素。悬浮球同样掩码。

### 4.3 什么时候算“没动”

- 最佳位移接近 0；
- 画面纹理方差过低（纯色背景）；
- 干净区域占比 < 18%（满屏都是译文块时）。

这些情况下返回零位移、置信度 0，悬浮层逐渐衰减速度而不是乱跳。

---

## 5. 运动外推（OverlayController）

采集只有 24fps，直接按采集节拍移动译文块会产生可见的“台阶感”。做法：

```
测量值：(scrollX, scrollY, 瞬时速度 v) @ t_measure
渲染值：scroll(t) = scroll_base + v × min(t - t_measure, 60ms)
```

- 每个 Choreographer 帧（60/120Hz）重新计算并 `invalidate()`；
- 外推最多 60ms（`MAX_PREDICTION_SEC`），防止急停后过冲；
- 新测量到达时基值跳回真实值，速度做 `v = 0.55v + 0.45v_new` 平滑；
- 超过 250ms 没有新测量（采集停了/暂停了），吸附到最后一个真实位置并停止回调。

急停时最坏情况是 60ms 的轻微过冲然后一次校正；相比“每个字都等 OCR”这是可接受的体验取舍。

---

## 6. 为什么没有拖影

| 常见拖影来源 | 本项目的对策 |
| --- | --- |
| 半透明底，原文透出 | 译文块背景**完全不透明**，颜色由 OCR 框外圈采样（ColorSampler 取中位数），和原背景融为一体 |
| 硬件层缓存旧像素 | 显式 `LAYER_TYPE_NONE`，整层每帧全量重绘 |
| 逐帧创建/销毁 View | 不创建任何子 View，只有一张全屏 View，`onDraw` 循环 `drawBitmap` |
| UI 线程排版/网络 | 文字排版（StaticLayout）和翻译都在后台单线程，结果做成 Bitmap 才上屏 |
| 移动中做半透明渐入动画 | 不透明度动画只允许“出现”瞬间短促完成；运动期间恒为 1.0 |

`PatchRenderer` 每个块只渲染一次：测量字号（按原行高的 0.62 起，最小 9sp）、限制行数（单行原文最多 2 行、多行原文最多 6 行）、自动缩小直到装下、居中或左对齐，最后连同圆角背景画进一张 Bitmap。

---

## 7. 识别与翻译的节流、去重与遮挡

- **单飞 OCR**：`ocrBusy` 保证同时只有一个 OCR 任务；任务忙时新帧直接跳过（丢帧优于排队）。
- **快照复用**：`BitmapPool(3)` 复用 ~3MB 的 OCR 快照，避免 GC 抖动。
- **行分组**：ML Kit 行按“垂直间隙 ≤ 0.7 行高、水平重叠 ≥ 30%、行高比 0.55~1.8”合并成段落，整段翻译，减少碎片化补丁。
- **遮挡过滤**：OCR 框与已渲染译文块的交集 > 35% 时丢弃——因为那个区域本来就已经翻译完，识别出来的多半是我们自己的译文。
- **翻译记忆**：`LRU(1500)` + 落盘 JSON（防抖 1.2s 写盘）。键 = `源语言>目标语言|归一化文本`。回看秒出。
- **重复抑制**：`pendingKeys` 防止同一段文字并发请求两次；`BlockStore.add` 按“同 key 且新框与旧框（换算到新锚点）重叠 > 20%”去重，重复出现的“确定/OK”按钮在不同位置仍然各自渲染。
- **失败退避**：翻译失败后 3.5s 内不再发起新请求，避免云端 429 循环。

---

## 8. 线程与同步模型

| 线程 | 职责 | 只碰什么 |
| --- | --- | --- |
| main | WindowManager、Choreographer、通知、状态流 | `OverlayController` 的运动状态；`BlockStore` 的发布走 `handler.post` |
| capture（HandlerThread） | ImageReader 回调、帧转换、ScrollEstimator | `TranslationPipeline.scrollX/Y`、`BitmapPool` |
| ocr-translate（单线程协程 dispatcher） | OCR、翻译、排版、贴图生成 | `TranslationMemory`、`BlockStore`（内部有锁） |
| memory IO（单线程 executor） | 翻译记忆落盘 | 只写自己的文件 |

`BlockStore` 用 `synchronized` + 不可变快照 List：读方拿到的是快照引用，写方整体替换列表，不存在“画到一半的列表”。

---

## 9. MediaProjection 生命周期（Android 14 重点）

1. Activity 拿到用户录屏授权（`createScreenCaptureIntent`）。
2. `TranslationService` **先** `ServiceCompat.startForeground(..., FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)`，**再** `getMediaProjection()`——Android 14 要求先有前台服务。
3. 注册 `MediaProjection.Callback`，`onStop`（用户从系统提示里撤销）→ 整体停机。
4. `VirtualDisplay` 用 `AUTO_MIRROR`；转屏时**不重新 `createVirtualDisplay`**（一次授权只能创建一个会话），而是 `setSurface(newReader.surface)` + `resize(...)` 复用同一个 VirtualDisplay。
5. 停止顺序：capture → coroutine scope → OCR/translator close → memory flush → overlay hide → projection.stop → stopForeground。

---

## 10. 已知失败模式与缓解

| 模式 | 表现 | 缓解 |
| --- | --- | --- |
| 满屏译文块，干净像素 <18% | 滚动估计失明 | 静止后再 OCR 会自然减少块；置信度 0 时不乱动 |
| 游戏内镜头缩放/转场 | 帧差误报 | 纹理+误差阈值过滤；停止后自动校正 |
| 竖排日文 | 分组成窄列，译文排版可能不理想 | 后续版本加竖排分组策略 |
| FLAG_SECURE 页面 | 采集到黑屏 | 无法绕过，文档明示 |
| 预测过冲（急停） | 块略微越位后跳回 | 60ms 外推上限 + 250ms 吸附 |
| 云端 429/超时 | 暂时无新译文 | 3.5s 退避 + 缓存兜底 |

---

## 11. 调参速查

见 `Tuning.kt`，README 有对照表。原则：

- 觉得“跟手但抖动” → 提 `TARGET_FPS`，不动 `MAX_PREDICTION_SEC`；
- 觉得“急停会弹一下” → 降 `MAX_PREDICTION_SEC` 到 0.04；
- 低端机发热 → 降 `TARGET_FPS` / `CAPTURE_SCALE`，提 `OCR_INTERVAL_MS`；
- 新文字出现太慢 → 降 `OCR_INTERVAL_MS`（注意发热）。

---

## 12. 未来方向

- 用无障碍 `TYPE_VIEW_SCROLLED` 事件做运动估计的补充/校验（部分 App 提供精确 delta）。
- 滚动时只 OCR 新露出的“条带”，进一步降低 CPU。
- 竖排日文分组与气泡轮廓贴合。
- 区域选择模式：只翻译屏幕的一部分。
- 句子级上下文缓存（当前按 OCR 段落翻译，不跨段）。
