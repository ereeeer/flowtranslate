# 手把手：把「流译」传到 GitHub 并拿到 APK

> 全程零编程知识也可以完成。分两条路线：
>
> - **路线 A（推荐）**：网页点几下 + 复制几条命令。15 分钟。
> - **路线 B**：用 GitHub Desktop 图形界面，几乎不用命令行。20 分钟。
>
> 两条路线最后都能在 GitHub Actions 上自动构建出 APK。

---

## 0. 你需要准备什么

| 东西 | 说明 |
| --- | --- |
| GitHub 账号 | 免费注册：https://github.com/signup |
| 一台电脑 | Windows / macOS / Linux 都行 |
| 一个 Android 手机 | Android 8.0 及以上 |
| 本项目文件夹 | `flowtranslate`（你现在拿到的这份代码） |

可选：Git 客户端（路线 A 需要，见下一节）；GitHub Desktop（路线 B 需要）。

---

## 路线 A：网页 + Git 命令

### A1. 安装 Git

Windows：到 https://git-scm.com/download/win 下载安装包，一路下一步（全部默认即可）。

macOS：

```bash
xcode-select --install
# 或
brew install git
```

Linux（Debian/Ubuntu）：

```bash
sudo apt update && sudo apt install git -y
```

验证安装成功：

```bash
git --version
```

### A2. 配置 Git 身份

打开终端（Windows 用 PowerShell 或「Git Bash」），执行：

```bash
git config --global user.name "你的名字"
git config --global user.email "你的邮箱@example.com"
```

邮箱用你注册 GitHub 的那个。

### A3. 在 GitHub 上建仓库

1. 打开 https://github.com/new
2. `Repository name` 填 `flowtranslate`
3. 选 **Public**（或 Private，都行）
4. **不要**勾选 “Add a README file”、`.gitignore`、`license`（本项目已经自带，勾了会冲突）
5. 点 **Create repository**
6. 记下仓库地址，形如：`https://github.com/你的用户名/flowtranslate.git`

### A4. 把代码推上去

在终端里进入项目文件夹：

```bash
cd flowtranslate
```

然后依次执行：

```bash
git init -b main
```

> 如果提示 `unknown option: -b`，说明 Git 版本太老，改用：
>
> ```bash
> git init
> git branch -M main
> ```

```bash
git add .
git commit -m "feat: 实时滚动屏幕翻译器"
git remote add origin https://github.com/你的用户名/flowtranslate.git
git push -u origin main
```

`git push` 时如果弹出登录：

- **用户名**：你的 GitHub 用户名
- **密码**：粘贴你的 Personal Access Token（不是 GitHub 登录密码！）

### A5. 申请 Personal Access Token（PAT）

GitHub 从 2021 年起不允许用账号密码推送。拿一个 Token：

1. GitHub 右上角头像 → **Settings**
2. 左侧最底部 **Developer settings**
3. **Personal access tokens** → **Tokens (classic)**
4. **Generate new token (classic)**
5. Note 随便填，比如 `flowtranslate`
6. 过期时间选 `90 days` 或 `No expiration`
7. 勾选 **repo**（整个分组勾上）
8. 点 **Generate token**，把 `ghp_...` 开头的一串**立刻复制保存**（只显示一次）
9. 回到终端，把它粘贴到密码提示里

Windows 上的 Git 会记住凭据（Git Credential Manager），下次推送不用再输。

### A6. 用 Actions 构建 APK

1. 打开你的仓库网页 `https://github.com/你的用户名/flowtranslate`
2. 点顶部 **Actions** 标签
3. 如果页面问是否启用 Actions，点绿色 **I understand my workflows, go ahead and enable them**
4. 左侧选择 **Build APK** → 右侧 **Run workflow** → **Run workflow**
5. 等任务跑完（2~5 分钟），点进这次运行
6. 页面底部 **Artifacts** 区域点 **flowtranslate-debug-apk**
7. 下载解压，得到 `app-debug.apk`

> 每次 `git push` 到 `main` 分支，这个构建都会自动重跑，所以改完代码推送后直接来 Actions 拿新 APK 即可。

### A7. 把 APK 装到手机

方式一（最简单）：

- 把 `app-debug.apk` 通过微信/QQ/网盘/数据线传到手机
- 点开 APK 文件，允许「安装未知应用」
- 安装完成

方式二（USB + adb）：

```bash
adb install app-debug.apk
```

> **注意**：GitHub 每次全新构建会使用缓存的同一个调试签名，所以新版本可以直接覆盖安装。如果你之前装过「本地 Android Studio 构建」的版本，签名不同，需要先卸载再安装（或在手机上点“覆盖安装失败 → 卸载重装”）。

---

## 路线 B：GitHub Desktop（图形界面）

1. 下载安装 GitHub Desktop：https://desktop.github.com
2. 登录你的 GitHub 账号
3. `File → New repository…`
   - Name 填 `flowtranslate`
   - Local path 选到 `flowtranslate` 的**上一级**文件夹（软件会自动把项目作为仓库打开）
   - 点 **Create repository**
4. 左侧面板会出现改动列表，底部 **Summary** 填 `feat: 实时滚动屏幕翻译器`，点 **Commit to main**
5. 点顶部 **Publish repository**，勾掉 “Keep this code private” 可以设成公开，点 **Publish repository**
6. 打开网页版仓库 → **Actions** → 按路线 A 的 A6 继续（跑 workflow、下载 Artifact）

以后改代码，在 GitHub Desktop 里填 Summary → **Commit to main** → **Push origin** 即可。

---

## 8. 更新代码 / 日常迭代

本地改完代码后：

```bash
git status                 # 看改了哪些文件
git add .
git commit -m "fix: 修复某某问题"
git push
```

然后去 Actions 拿新 APK。

常用小抄：

| 命令 | 作用 |
| --- | --- |
| `git status` | 查看当前改动 |
| `git diff` | 查看改动内容 |
| `git log --oneline` | 查看提交历史 |
| `git pull` | 拉取远端更新 |
| `git push` | 推送本地提交 |

---

## 9. 发一个 Release（可选，让下载更正式）

```bash
git tag v0.1.0
git push origin v0.1.0
```

然后打开仓库 → **Releases** → **Draft a new release** → 选择 tag `v0.1.0`，把 Actions 下载的 APK 作为附件上传。

---

## 10. 常见报错对照表

| 报错 / 现象 | 原因与解决 |
| --- | --- |
| `git: command not found` | 没装 Git，见 A1 |
| `fatal: not a git repository` | 没有先 `git init`，或终端不在 `flowtranslate` 目录里（`cd` 进去） |
| `src refspec main does not match any` | 还没有任何 commit，先 `git add .` + `git commit` |
| `remote origin already exists` | 已经添加过远程，用 `git remote set-url origin https://github.com/你的用户名/flowtranslate.git` 替换 |
| `! [rejected] main -> main (fetch first)` | 远端有本地没有的内容，执行 `git pull --rebase origin main` 再 push |
| `Support for password authentication was removed` | 你在用账号密码推送，改用 PAT（见 A5） |
| `403` / `Authentication failed` | Token 没权限或复制错了；Token 需要勾选 `repo` |
| Actions 里构建失败 | 点进失败步骤看日志：最常见是依赖下载超时，点右上角 **Re-run all jobs** 重试；仍失败请把日志发 Issue |
| APK 无法覆盖安装 | 新旧 APK 签名不一致（例如一个来自本地 Android Studio、一个来自 Actions），卸载旧的再装 |
| 手机提示“应用未安装” | 检查是否允许安装未知应用；确认 APK 完整（下载的 zip 已解压） |
| 无障碍开关是灰的 | Android 13+ 受限设置：设置 → 应用 → 流译 → 右上角 ⋮ → 允许受限设置 |

---

## 11. 绝对不要提交的东西

`.gitignore` 已经帮你挡掉了大部分，但注意：

- **API Key**：不要写进代码文件（本项目的 Key 是在 App 设置里输入的，不会进仓库）
- **`local.properties`**：本机 SDK 路径，已被 `.gitignore` 忽略
- **`*.jks` / `*.keystore`**：正式版签名密钥，丢了就不能覆盖升级，也绝对不要公开
- **`build/`**：构建产物，已被忽略

---

## 12. 进阶：本地构建

如果你想在自己电脑上改代码并打包，见 [README](../README.md) 的「本地构建」一节。本地构建的 APK 与 Actions 构建的 APK 签名不同，覆盖安装时需要先卸载。
