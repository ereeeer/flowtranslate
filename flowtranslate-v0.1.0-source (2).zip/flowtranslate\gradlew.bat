@echo off
rem Lightweight Gradle bootstrap. Downloads Gradle 8.7 on first run.
rem This keeps the repository free of a binary wrapper JAR while remaining
rem usable from Android Studio and from a terminal.
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\gradle.ps1" %*
exit /b %ERRORLEVEL%
