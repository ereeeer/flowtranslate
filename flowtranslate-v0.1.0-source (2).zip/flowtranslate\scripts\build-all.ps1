﻿# ===========================================================================
# 流译 · 一键构建 APK（全自动，全程国内镜像）
# 你什么都不用懂：双击「一键构建APK.bat」，等它跑完，APK 自己弹出来。
# ===========================================================================

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $root

# 全程记录到日志文件，窗口就算关了也能看到发生过什么
$log = Join-Path $root "构建日志.txt"
try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null } catch { }
try { Start-Transcript -Path $log -Append -ErrorAction SilentlyContinue | Out-Null } catch { }

trap {
    Write-Host ""
    Write-Host ("出错了：" + $_.Exception.Message) -ForegroundColor Red
    Write-Host "别慌：打开项目文件夹里的【构建日志.txt】，把内容发我，我告诉你怎么修。" -ForegroundColor Yellow
    try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null } catch { }
    Read-Host "按回车键关闭"
    exit 1
}

function Say([string]$msg) {
    Write-Host ""
    Write-Host $msg -ForegroundColor Cyan
}

function Fail([string]$msg) {
    Write-Host ""
    Write-Host $msg -ForegroundColor Red
    Write-Host "别关这个窗口。打开文件夹里的【构建日志.txt】，把内容发我，我帮你看。" -ForegroundColor Yellow
    Read-Host "按回车键关闭"
    exit 1
}

function Find-Java {
    if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME "bin\java.exe"))) {
        return (Join-Path $env:JAVA_HOME "bin\java.exe")
    }
    $cmd = Get-Command java.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $candidates = @(
        "$env:ProgramFiles\Android\Android Studio\jbr\bin\java.exe",
        "$env:ProgramFiles\Java\jdk-17\bin\java.exe",
        "$env:ProgramFiles\Java\jdk-21\bin\java.exe",
        "$env:ProgramFiles\Microsoft\jdk-17*\bin\java.exe",
        "$env:ProgramFiles\Eclipse Adoptium\jdk-17*\bin\java.exe",
        "$env:LOCALAPPDATA\Programs\Eclipse Adoptium\jdk-17*\bin\java.exe",
        "${env:ProgramFiles(x86)}\Java\jdk-17\bin\java.exe"
    )
    foreach ($p in $candidates) {
        $hit = Get-Item $p -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($hit) { return $hit.FullName }
    }
    return $null
}

function Download-File([string[]]$urls, [string]$dest) {
    foreach ($u in $urls) {
        Write-Host ("  下载: " + $u)
        try {
            Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile $dest -TimeoutSec 1800
            return $true
        } catch {
            Write-Host "  失败，换下一个地址…"
        }
    }
    return $false
}

Write-Host "======================================" -ForegroundColor Cyan
Write-Host "  流译 · 一键构建 APK" -ForegroundColor Cyan
Write-Host "  第一次运行需要下载约 1GB，请用 WiFi" -ForegroundColor Cyan
Write-Host "  窗口就算关了，进度都在【构建日志.txt】里" -ForegroundColor Cyan
Write-Host "======================================" -ForegroundColor Cyan

# ---------------------------------------------------------------------------
# 第 1 步：Java
# ---------------------------------------------------------------------------
Say "第 1/3 步：准备 Java（第一次约 200MB，以后跳过）…"

$java = Find-Java
$javaHome = $null
if (-not $java) {
    Write-Host "电脑里没有 Java，正在自动下载（华为云镜像）…"
    $jdkBase = Join-Path $env:LOCALAPPDATA "flowtranslate\jdk"
    $javaExe = Join-Path $jdkBase "jdk-17.0.2\bin\java.exe"
    if (-not (Test-Path $javaExe)) {
        $zip = Join-Path $env:TEMP "openjdk-17.0.2_windows-x64_bin.zip"
        $jdkUrl = "https://mirrors.huaweicloud.com/openjdk/17.0.2/openjdk-17.0.2_windows-x64_bin.zip"
        if (-not (Download-File @($jdkUrl) $zip)) {
            Fail "Java 下载失败：请检查网络（能打开网页就行），然后重新双击运行。"
        }
        New-Item -ItemType Directory -Force -Path $jdkBase | Out-Null
        Write-Host "解压 Java …"
        Expand-Archive -Path $zip -DestinationPath $jdkBase -Force
        Remove-Item $zip -Force
    }
    $java = $javaExe
    $javaHome = Split-Path -Parent (Split-Path -Parent $javaExe)
} else {
    if ($env:JAVA_HOME) {
        $javaHome = $env:JAVA_HOME
    } else {
        $javaHome = Split-Path -Parent (Split-Path -Parent $java)
    }
}
$env:JAVA_HOME = $javaHome
$versionLine = & $java -version 2>&1 | Select-Object -First 1
Write-Host "Java 就绪：$versionLine" -ForegroundColor Green

# ---------------------------------------------------------------------------
# 第 2 步：Android SDK
# ---------------------------------------------------------------------------
Say "第 2/3 步：准备安卓 SDK（第一次约 600MB，以后跳过）…"

$sdkRoot = if ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { Join-Path $env:LOCALAPPDATA "Android\Sdk" }
$platformOk = Test-Path (Join-Path $sdkRoot "platforms\android-34\android.jar")
$buildToolsOk = Test-Path (Join-Path $sdkRoot "build-tools\34.0.0\aapt.exe")

if (-not ($platformOk -and $buildToolsOk)) {
    New-Item -ItemType Directory -Force -Path $sdkRoot | Out-Null
    $mirror = "https://mirrors.cloud.tencent.com/AndroidSDK"
    $official = "https://dl.google.com/android/repository"

    $xmlPath = Join-Path $env:TEMP "flow-repository2-3.xml"
    if (-not (Download-File @("$mirror/repository2-3.xml", "$official/repository2-3.xml") $xmlPath)) {
        Fail "下载安卓组件列表失败：请检查网络后重新运行。"
    }
    [xml]$repo = Get-Content -Raw $xmlPath
    $packages = @($repo.'sdk-repository'.remotePackage)

    function Get-ArchiveUrl([string]$pathLike) {
        foreach ($pkg in $packages) {
            if ($pkg.path -ne $pathLike) { continue }
            $archives = @($pkg.archive)
            if ($archives.Count -eq 0) { return $null }
            $win = $archives | Where-Object { $_.'host-os' -eq 'windows' } | Select-Object -First 1
            $pick = if ($win) { $win } else { $archives[0] }
            $url = $pick.url
            if (-not $url -and $pick.complete) { $url = $pick.complete.url }
            return [string]$url
        }
        return $null
    }

    function Install-Package([string]$pathLike, [string]$targetDir) {
        $name = Get-ArchiveUrl $pathLike
        if (-not $name) {
            Write-Host ("  列表里找不到 " + $pathLike + "，跳过") -ForegroundColor Yellow
            return
        }
        $zip = Join-Path $env:TEMP $name
        if (-not (Download-File @("$mirror/$name", "$official/$name") $zip)) {
            Write-Host ("  下载失败: " + $name) -ForegroundColor Red
            return
        }
        $tmp = Join-Path $env:TEMP ("flow-sdk-" + [guid]::NewGuid().ToString("N"))
        New-Item -ItemType Directory -Path $tmp | Out-Null
        Expand-Archive -Path $zip -DestinationPath $tmp -Force
        Remove-Item $zip -Force
        $src = $tmp
        $entries = @(Get-ChildItem -Path $tmp)
        if ($entries.Count -eq 1 -and $entries[0].PSIsContainer) { $src = $entries[0].FullName }
        New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
        Copy-Item -Path (Join-Path $src '*') -Destination $targetDir -Recurse -Force
        Remove-Item $tmp -Recurse -Force
        Write-Host ("  已安装: " + $targetDir) -ForegroundColor Green
    }

    if (-not $platformOk) {
        Write-Host "下载安卓平台 android-34 …"
        Install-Package "platforms;android-34" (Join-Path $sdkRoot "platforms\android-34")
    }
    if (-not $buildToolsOk) {
        Write-Host "下载安卓构建工具 34.0.0 …"
        Install-Package "build-tools;34.0.0" (Join-Path $sdkRoot "build-tools\34.0.0")
    }
    if (-not (Test-Path (Join-Path $sdkRoot "platform-tools\adb.exe"))) {
        Write-Host "下载 platform-tools（传 APK 到手机用）…"
        Install-Package "platform-tools" (Join-Path $sdkRoot "platform-tools")
    }

    $licDir = Join-Path $sdkRoot "licenses"
    New-Item -ItemType Directory -Force -Path $licDir | Out-Null
    "8933bad161af4178b1185d1a37fbf41ea5269c55" | Out-File -FilePath (Join-Path $licDir "android-sdk-license") -Encoding ascii

    if (-not (Test-Path (Join-Path $sdkRoot "platforms\android-34\android.jar"))) {
        Fail "安卓平台下载不完整。请重新双击运行一次，脚本会接着上次继续。"
    }
}

$env:ANDROID_HOME = $sdkRoot
$propsPath = Join-Path $root "local.properties"
"sdk.dir=" + ($sdkRoot -replace '\\', '/') | Set-Content -Path $propsPath -Encoding ascii
Write-Host "安卓 SDK 就绪。" -ForegroundColor Green

# ---------------------------------------------------------------------------
# 第 3 步：编译
# ---------------------------------------------------------------------------
Say "第 3/3 步：编译 APK（第一次要下载依赖，约 10~20 分钟，耐心等）…"

& (Join-Path $root "scripts\gradle.ps1") ":app:assembleDebug"
if ($LASTEXITCODE -ne 0) {
    Fail "编译失败。请把本窗口最上面的报错文字整屏截图发我。"
}

$apk = Join-Path $root "app\build\outputs\apk\debug\app-debug.apk"
if (-not (Test-Path $apk)) {
    Fail "编译完成但没找到 APK 文件，请把本窗口截图发我。"
}

Write-Host ""
Write-Host "==============================" -ForegroundColor Green
Write-Host "  构建成功！" -ForegroundColor Green
Write-Host "  APK 文件：" -ForegroundColor Green
Write-Host "  $apk" -ForegroundColor White
Write-Host "==============================" -ForegroundColor Green
Write-Host ""
Write-Host "下一步："
Write-Host "  1. 把 app-debug.apk 传到手机，点开安装（允许未知来源）"
Write-Host "  2. 打开「流译」→ 开启无障碍服务"
Write-Host "  3. 点「开始翻译」→ 允许录屏"
Write-Host "  4. 回到小说/漫画/游戏/网页，正常滑动即可"
Write-Host ""
Start-Process explorer.exe "/select,$apk"
Read-Host "按回车键关闭窗口"
