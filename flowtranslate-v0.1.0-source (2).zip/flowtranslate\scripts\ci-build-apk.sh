#!/usr/bin/env bash
# ============================================================================
# FlowTranslate · Gitee Go 云打包入口
# 在 Gitee 云端构建机上：装 JDK 工具链 → 装 Android SDK → 编译 debug APK
# 这个文件会被 .workflow/android-apk.yml 调用，也可以本地 Linux/macOS 跑。
# ============================================================================
set -eo pipefail

SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/android-sdk}}"
ANDROID_API="${ANDROID_API:-34}"
BUILD_TOOLS="${BUILD_TOOLS:-34.0.0}"
CMDLINE_TOOLS="${CMDLINE_TOOLS:-11076708}"
MIRROR="https://mirrors.cloud.tencent.com/AndroidSDK"
OFFICIAL="https://dl.google.com/android/repository"

log() { printf '\n=== %s ===\n' "$*"; }
die() { printf '\n!! %s\n' "$*" >&2; exit 1; }

fetch() { # fetch <url> <out>
  local url="$1" out="$2"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL --retry 3 --retry-delay 2 -o "$out" "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -q --tries=3 --timeout=180 -O "$out" "$url"
  elif command -v python3 >/dev/null 2>&1; then
    python3 -c 'import sys,urllib.request;urllib.request.urlretrieve(sys.argv[1],sys.argv[2])' "$url" "$out"
  else
    die "没有 curl / wget / python3，无法下载"
  fi
}

unzip_into() { # unzip_into <zip> <destdir>
  local zip="$1" dest="$2"
  mkdir -p "$dest"
  if command -v unzip >/dev/null 2>&1; then
    unzip -q -o "$zip" -d "$dest"
  else
    ( cd "$dest" && "$JAVA_HOME/bin/jar" xf "$zip" )
  fi
}

# ---------------------------------------------------------------- Java ------
if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then
  JAVA_BIN="$JAVA_HOME/bin/java"
else
  JAVA_BIN="$(command -v java)" || die "缺少 JDK 17（Gitee Go 里由 jdkVersion: 17 提供）"
  JAVA_REAL="$(readlink -f "$JAVA_BIN" 2>/dev/null || echo "$JAVA_BIN")"
  JAVA_HOME="$(dirname "$(dirname "$JAVA_REAL")")"
  export JAVA_HOME
fi
export PATH="$JAVA_HOME/bin:$PATH"
log "Java: $("$JAVA_BIN" -version 2>&1 | head -n 1 || true)"

# ------------------------------------------------------------ Android SDK ---
mkdir -p "$SDK_ROOT"
SDKMANAGER="$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
if [ ! -x "$SDKMANAGER" ] && [ ! -f "$SDKMANAGER.bat" ]; then
  log "下载 Android 命令行工具（腾讯云镜像优先，失败切官方源）"
  tmp="$(mktemp -d)"
  if ! fetch "$MIRROR/commandlinetools-linux-${CMDLINE_TOOLS}_latest.zip" "$tmp/ct.zip"; then
    log "腾讯云镜像不可用，改用官方源"
    fetch "$OFFICIAL/commandlinetools-linux-${CMDLINE_TOOLS}_latest.zip" "$tmp/ct.zip" \
      || die "命令行工具下载失败"
  fi
  unzip_into "$tmp/ct.zip" "$tmp/ct"
  mkdir -p "$SDK_ROOT/cmdline-tools"
  rm -rf "$SDK_ROOT/cmdline-tools/latest" 2>/dev/null || true
  if [ -d "$tmp/ct/cmdline-tools" ]; then
    mv "$tmp/ct/cmdline-tools" "$SDK_ROOT/cmdline-tools/latest"
  else
    mv "$tmp/ct" "$SDK_ROOT/cmdline-tools/latest"
  fi
  rm -rf "$tmp"
fi
[ -f "$SDKMANAGER" ] || die "sdkmanager 不可用：$SDKMANAGER"

export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export PATH="$SDK_ROOT/cmdline-tools/latest/bin:$SDK_ROOT/platform-tools:$PATH"

log "接受 Android SDK 许可"
for _ in $(seq 1 80); do echo y; done \
  | "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --licenses >/dev/null 2>&1 || true

log "安装 platform-tools / platforms;android-${ANDROID_API} / build-tools;${BUILD_TOOLS}"
"$SDKMANAGER" --sdk_root="$ANDROID_HOME" --install \
  "platform-tools" \
  "platforms;android-${ANDROID_API}" \
  "build-tools;${BUILD_TOOLS}" || die "Android SDK 组件安装失败"

# ---------------------------------------------------------------- Build -----
cd "$(dirname "$0")/.."
printf 'sdk.dir=%s\n' "$(printf '%s' "$ANDROID_HOME" | tr '\\' '/')" > local.properties
chmod +x gradlew 2>/dev/null || true

log "开始编译：:app:assembleDebug"
bash gradlew :app:assembleDebug --no-daemon --stacktrace

log "APK 产物："
find app/build/outputs/apk -type f -name '*.apk' -print
