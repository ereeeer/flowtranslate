﻿# 环境诊断：生成 诊断报告.txt，供开发者定位问题
$ErrorActionPreference = "Continue"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $root
$report = Join-Path $root "诊断报告.txt"

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("==== 流译环境诊断 ====")
$lines.Add("时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
$lines.Add("当前目录: $root")
$lines.Add("")
$lines.Add("--- 系统 ---")
try { $lines.Add((Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, OSArchitecture | Format-List | Out-String).Trim()) } catch { $lines.Add("读取系统信息失败: $($_.Exception.Message)") }
$lines.Add("")
$lines.Add("--- PowerShell ---")
$lines.Add("版本: $($PSVersionTable.PSVersion)")
try { $lines.Add("执行策略: $((Get-ExecutionPolicy -List | Out-String).Trim())") } catch { $lines.Add("读取执行策略失败") }
$lines.Add("")
$lines.Add("--- Java ---")
$javaCmd = Get-Command java.exe -ErrorAction SilentlyContinue
if ($javaCmd) {
    $lines.Add("路径: $($javaCmd.Source)")
    try { $lines.Add((& $javaCmd.Source -version 2>&1 | Out-String).Trim()) } catch { $lines.Add("java 无法运行") }
} else {
    $lines.Add("PATH 中找不到 java")
}
$lines.Add("")
$lines.Add("--- 文件检查 ---")
foreach ($rel in @("settings.gradle.kts", "scripts\build-all.ps1", "scripts\gradle.ps1", "app\build.gradle.kts", "app\src\main\AndroidManifest.xml", "gradlew.bat")) {
    $p = Join-Path $root $rel
    $status = "MISS"
    if (Test-Path $p) { $status = "OK  " }
    $lines.Add(("{0}  {1}" -f $status, $rel))
}
$lines.Add("")
$lines.Add("--- 根目录文件 ---")
try { $lines.Add(((Get-ChildItem -Name | Out-String).Trim())) } catch { }
$lines.Add("")
$lines.Add("--- 是否在压缩包临时目录 ---")
if ($root -like "*AppData\Local\Temp*") {
    $lines.Add("警告：当前在临时目录，可能没有完整解压！")
} else {
    $lines.Add("正常（不在临时目录）")
}
$lines.Add("")
$lines.Add("==== 诊断结束 ====")

$lines | Out-File -FilePath $report -Encoding UTF8
Write-Host ""
foreach ($line in $lines) { Write-Host $line -ForegroundColor Gray }
Write-Host ""
Write-Host "已生成诊断报告：$report" -ForegroundColor Green
Write-Host "请把这个文件（或整屏截图）发给开发者。" -ForegroundColor Yellow
Read-Host "按回车键关闭"
