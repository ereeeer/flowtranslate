﻿$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# 轻量 Gradle 引导脚本（Windows）
# 1. 自动寻找 JDK 17+（JAVA_HOME → Android Studio 自带 JBR → 常见安装目录）
# 2. 自动下载 Gradle 8.7（国内镜像优先，官方源兜底）
# ---------------------------------------------------------------------------

$version = "8.7"

function Find-Java {
    # 1) JAVA_HOME
    if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME "bin\java.exe"))) {
        return (Join-Path $env:JAVA_HOME "bin\java.exe")
    }
    # 2) PATH 上的 java
    $cmd = Get-Command java.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    # 3) 常见安装位置
    $candidates = @(
        "$env:ProgramFiles\Android\Android Studio\jbr\bin\java.exe",
        "$env:ProgramFiles\Java\jdk-17\bin\java.exe",
        "$env:ProgramFiles\Java\jdk-21\bin\java.exe",
        "$env:ProgramFiles\Microsoft\jdk-17*\bin\java.exe",
        "$env:ProgramFiles\Eclipse Adoptium\jdk-17*\bin\java.exe",
        "$env:LOCALAPPDATA\Programs\Eclipse Adoptium\jdk-17*\bin\java.exe",
        "${env:ProgramFiles(x86)}\Java\jdk-17\bin\java.exe"
    )
    foreach ($p in $candidates) {
        $hit = Get-Item $p -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($hit) { return $hit.FullName }
    }
    return $null
}

$java = Find-Java
if (-not $java) {
    Write-Host "找不到 Java。请先安装 JDK 17：" -ForegroundColor Red
    Write-Host "  1. 华为镜像: https://mirrors.huaweicloud.com/openjdk/17.0.2/openjdk-17.0.2_windows-x64_bin.zip"
    Write-Host "  2. 清华镜像: https://mirrors.tuna.tsinghua.edu.cn/Adoptium/17/jdk/x64/windows/"
    Write-Host "  3. 或直接安装 Android Studio（自带 JDK）：https://developer.android.google.cn/studio"
    Write-Host ""
    Write-Host "解压后把路径设置到环境变量 JAVA_HOME（例如 C:\jdk-17.0.2），或把 bin 目录加进 PATH。"
    exit 1
}

# 校验主版本 >= 17
$verOutput = & $java -version 2>&1 | Select-Object -First 1
Write-Host "使用 Java: $java ($verOutput)"

$gradleHome = Join-Path $env:USERPROFILE ".gradle\flowtranslate\gradle-$version"
$gradleBat = Join-Path $gradleHome "bin\gradle.bat"

if (-not (Test-Path $gradleBat)) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $urls = @()
    if ($env:GRADLE_DIST_URL) { $urls += $env:GRADLE_DIST_URL }
    $urls += @(
        "https://mirrors.cloud.tencent.com/gradle/gradle-$version-bin.zip",
        "https://mirrors.huaweicloud.com/gradle/gradle-$version-bin.zip",
        "https://services.gradle.org/distributions/gradle-$version-bin.zip"
    )

    $zip = Join-Path $env:TEMP "gradle-$version-bin.zip"
    $parent = Split-Path -Parent $gradleHome
    New-Item -ItemType Directory -Force -Path $parent | Out-Null
    $ok = $false
    foreach ($url in $urls) {
        Write-Host "下载 Gradle $version（首次构建需要，约 130 MB）：$url"
        try {
            Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing -TimeoutSec 600
            Expand-Archive -Path $zip -DestinationPath $parent -Force
            Remove-Item $zip -Force
            if (Test-Path $gradleBat) { $ok = $true; break }
        } catch {
            Write-Host "  失败：$($_.Exception.Message.Split([char]10)[0])，换下一个源…"
        }
    }
    if (-not $ok) {
        Write-Host "Gradle 下载失败。可以手动下载后解压到：$parent" -ForegroundColor Red
        Write-Host "下载地址（任一）："
        Write-Host "  https://mirrors.cloud.tencent.com/gradle/gradle-$version-bin.zip"
        Write-Host "  https://mirrors.huaweicloud.com/gradle/gradle-$version-bin.zip"
        Write-Host "  https://services.gradle.org/distributions/gradle-$version-bin.zip"
        exit 1
    }
}

if (-not $env:JAVA_HOME) {
    $env:JAVA_HOME = Split-Path -Parent (Split-Path -Parent $java)
}

& $gradleBat @args
exit $LASTEXITCODE
