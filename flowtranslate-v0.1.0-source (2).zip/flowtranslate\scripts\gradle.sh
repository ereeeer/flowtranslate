#!/usr/bin/env sh
# Lightweight Gradle bootstrap for macOS / Linux / Gitee CI.
# Downloads Gradle 8.7 on first run, trying Chinese mirrors before the official one.
set -eu

VERSION=8.7
GRADLE_HOME="${HOME}/.gradle/flowtranslate/gradle-${VERSION}"

if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
    URLS="${GRADLE_DIST_URL:-}"
    if [ -z "$URLS" ]; then
        URLS="https://mirrors.cloud.tencent.com/gradle/gradle-${VERSION}-bin.zip https://mirrors.huaweicloud.com/gradle/gradle-${VERSION}-bin.zip https://services.gradle.org/distributions/gradle-${VERSION}-bin.zip"
    fi
    TMP="${TMPDIR:-/tmp}/gradle-${VERSION}-bin.zip"
    mkdir -p "$(dirname "$GRADLE_HOME")"

    fetch() { # fetch <url> <out>
        if command -v curl >/dev/null 2>&1; then
            curl -fL --retry 3 --retry-delay 2 "$1" -o "$2"
        elif command -v wget >/dev/null 2>&1; then
            wget -q --tries=3 --timeout=180 -O "$2" "$1"
        elif command -v python3 >/dev/null 2>&1; then
            python3 -c 'import sys,urllib.request;urllib.request.urlretrieve(sys.argv[1],sys.argv[2])' "$1" "$2"
        else
            echo "Need curl, wget or python3 to download Gradle." >&2
            return 1
        fi
    }

    unzip_into() { # unzip_into <zip> <dest>
        if command -v unzip >/dev/null 2>&1; then
            unzip -q -o "$1" -d "$2"
        elif [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/jar" ]; then
            ( cd "$2" && "$JAVA_HOME/bin/jar" xf "$1" )
        else
            echo "Need unzip (or a JDK) to extract Gradle." >&2
            return 1
        fi
    }

    ok=0
    for url in $URLS; do
        echo "Downloading Gradle ${VERSION}: ${url}"
        rm -f "$TMP"
        fetch "$url" "$TMP" || continue
        unzip_into "$TMP" "$(dirname "$GRADLE_HOME")" || continue
        rm -f "$TMP"
        if [ -x "$GRADLE_HOME/bin/gradle" ]; then
            ok=1
            break
        fi
    done
    if [ "$ok" != "1" ]; then
        echo "Gradle download failed. Download manually and unpack to $(dirname "$GRADLE_HOME")" >&2
        exit 1
    fi
fi

exec "$GRADLE_HOME/bin/gradle" "$@"
