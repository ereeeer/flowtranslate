﻿# 自动安装 Android SDK（Windows，国内网络友好）
# 用法：在项目目录执行  powershell -ExecutionPolicy Bypass -File .\setup-sdk.ps1
# 它会从腾讯/官方源下载 command-line 组件：platforms;android-34、build-tools;34.0.0、platform-tools
# 并写入 licenses 与 local.properties。装完直接运行 build-apk.ps1 即可。

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$sdkRoot = if ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { Join-Path $env:LOCALAPPDATA "Android\Sdk" }
New-Item -ItemType Directory -Force -Path $sdkRoot | Out-Null

$mirror = "https://mirrors.cloud.tencent.com/AndroidSDK"
$official = "https://dl.google.com/android/repository"

function Download-File([string[]]$urls, [string]$dest) {
    foreach ($u in $urls) {
        Write-Host "  下载: $u"
        try {
            Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile $dest -TimeoutSec 1200
            return $true
        } catch {
            Write-Host "  失败，换下一个源…"
        }
    }
    return $false
}

Write-Host "SDK 目录: $sdkRoot" -ForegroundColor Cyan

# 1) 获取仓库索引（包含各组件 zip 的准确文件名）
$xmlPath = Join-Path $env:TEMP "flow-repository2-3.xml"
if (-not (Download-File @("$mirror/repository2-3.xml", "$official/repository2-3.xml") $xmlPath)) {
    Write-Host "无法下载仓库索引，请检查网络。" -ForegroundColor Red
    Read-Host "按回车键退出"
    exit 1
}

[xml]$repo = Get-Content -Raw $xmlPath
$packages = @($repo.'sdk-repository'.remotePackage)

function Get-ArchiveUrl([string]$pathLike) {
    foreach ($pkg in $packages) {
        if ($pkg.path -ne $pathLike) { continue }
        $archives = @($pkg.archive)
        if ($archives.Count -eq 0) { return $null }
        $win = $archives | Where-Object { $_.'host-os' -eq 'windows' } | Select-Object -First 1
        $pick = if ($win) { $win } else { $archives[0] }
        $url = $pick.url
        if (-not $url -and $pick.complete) { $url = $pick.complete.url }
        return [string]$url
    }
    return $null
}

function Install-Package([string]$pathLike, [string]$targetDir) {
    $name = Get-ArchiveUrl $pathLike
    if (-not $name) {
        Write-Host "  索引中找不到 $pathLike，跳过" -ForegroundColor Yellow
        return
    }
    $zip = Join-Path $env:TEMP $name
    if (-not (Download-File @("$mirror/$name", "$official/$name") $zip)) {
        Write-Host "  下载失败: $name" -ForegroundColor Red
        return
    }
    $tmp = Join-Path $env:TEMP ("flow-sdk-" + [guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $tmp | Out-Null
    Expand-Archive -Path $zip -DestinationPath $tmp -Force
    Remove-Item $zip -Force
    $src = $tmp
    $entries = @(Get-ChildItem -Path $tmp)
    if ($entries.Count -eq 1 -and $entries[0].PSIsContainer) { $src = $entries[0].FullName }
    New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
    Copy-Item -Path (Join-Path $src '*') -Destination $targetDir -Recurse -Force
    Remove-Item $tmp -Recurse -Force
    Write-Host "  安装完成: $targetDir" -ForegroundColor Green
}

Write-Host "安装 platforms;android-34 …"
Install-Package "platforms;android-34" (Join-Path $sdkRoot "platforms\android-34")

Write-Host "安装 build-tools;34.0.0 …"
Install-Package "build-tools;34.0.0" (Join-Path $sdkRoot "build-tools\34.0.0")

Write-Host "安装 platform-tools …"
Install-Package "platform-tools" (Join-Path $sdkRoot "platform-tools")

# 2) 接受 SDK 许可（写入 license 哈希文件）
$licDir = Join-Path $sdkRoot "licenses"
New-Item -ItemType Directory -Force -Path $licDir | Out-Null
"8933bad161af4178b1185d1a37fbf41ea5269c55" | Out-File -FilePath (Join-Path $licDir "android-sdk-license") -Encoding ascii
Write-Host "已接受 SDK 许可。" -ForegroundColor Green

# 3) 生成 local.properties
$propsPath = Join-Path $root "local.properties"
"sdk.dir=" + ($sdkRoot -replace '\\', '/') | Set-Content -Path $propsPath -Encoding ascii
Write-Host "已写入 local.properties。" -ForegroundColor Green

$env:ANDROID_HOME = $sdkRoot

Write-Host ""
Write-Host "SDK 准备完毕！下一步：运行 build-apk.ps1 开始编译。" -ForegroundColor Cyan
Read-Host "按回车键退出"
