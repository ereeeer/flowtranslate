@echo off
rem FlowTranslate one-click APK builder (ASCII-only launcher).
rem Chinese messages are printed by PowerShell, so this file can never be
rem garbled by the cmd.exe code page.
cd /d "%~dp0"

if not exist "%~dp0scripts\build-all.ps1" (
    echo.
    echo ERROR: scripts\build-all.ps1 not found.
    echo Please EXTRACT the whole zip to a folder first, then double-click again.
    echo Do not run this file from inside the zip preview window.
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build-all.ps1"

echo.
echo ==================================================
echo If you saw red error lines above:
echo   1. Open the .txt log file in this folder
echo   2. Send its content to the developer
echo If no error: the APK folder should have opened.
echo ==================================================
echo.
pause
