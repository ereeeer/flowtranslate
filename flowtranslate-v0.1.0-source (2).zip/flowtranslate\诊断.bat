@echo off
rem FlowTranslate diagnostic launcher (ASCII-only; Chinese report is produced by PowerShell).
cd /d "%~dp0"

if not exist "%~dp0scripts\diagnose.ps1" (
    echo.
    echo ERROR: scripts\diagnose.ps1 not found.
    echo Please extract the whole zip first.
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\diagnose.ps1"
pause
